/*!
 * @file add-TFout.cxx
 * @brief Add the output of the neural network building in TensorFlow
 * @author TCR
 * @date 7 June 2024
 * @version 1
 */

#include <TString.h>
#include <TMath.h>
#include <xcdf/XCDFField.h>
#include <xcdf/XCDFFile.h>
#include <xcdf/utility/XCDFUtility.h>
#include <hawcnest/CommandLineConfigurator.h>
#include <hawcnest/Logging.h>
#include <string>
#include <vector>
#include <iostream>
#include "redtf.h"

//using namespace std;



int main(int argc, char** argv) {
    int numevt = 0;
    int num_layers = 5;
    double prediction =-10;
    std::string config_dir;
    redtf nntf;
    
    CommandLineConfigurator cl(
                               "Append NN regresion"
                               "files."
                               );
    cl.AddPositionalOption<std::vector<std::string> >(
                                                      "in-files", "Input XCDF files.  Default is stdin."
                                                      );
    cl.AddOption<std::string>(
                              "out-file,o", "/dev/stdout", "Output XCDF file."
                              );
    OptionGroup& ct = cl.AddOptionGroup("Config files");
    ct.AddOption<std::string>(
                              "configdir", "nuevos_pesos", "directory of configuration"
                              );

    if (!cl.ParseCommandLine(argc, argv)) return EXIT_FAILURE;
    
    std::vector<std::string> inFileNames;
    
    if (cl.HasFlag("in-files"))
        inFileNames = cl.GetArgument<std::vector<std::string> >("in-files");
    else
        inFileNames.push_back("/dev/stdin");
    
    XCDFFile outFile(cl.GetArgument<std::string>("out-file").c_str(), "w");
    FieldCopyBuffer buffer(outFile);
    
    XCDFFloatingPointField tfout = outFile.AllocateFloatingPointField("rec.tfout",0.01);

    config_dir = cl.GetArgument<std::string>("configdir");
    std::cout << "CONFIG DIRECTORY: "<< config_dir << std::endl;
    
    std::string medias_desviaciones_file = config_dir + "/scaling_params.csv";
    nntf.ChargeScalingFile(medias_desviaciones_file);
    nntf.ChargeWeightsFiles(num_layers, config_dir);
    
    for (unsigned i = 0, n = inFileNames.size(); i < n; ++i) {
        XCDFFile inFile(inFileNames[i].c_str(), "r");
        //XCDFFloatingPointField rec_.GetFloatingPointField("rec.");
        //XCDFUnsignedIntegerField rec_.GetUnsignedIntegerField("rec.");
        XCDFUnsignedIntegerField rec_eventID= inFile.GetUnsignedIntegerField("rec.eventID");
        XCDFUnsignedIntegerField rec_nChAvail= inFile.GetUnsignedIntegerField("rec.nChAvail");
        XCDFUnsignedIntegerField rec_nHitTot= inFile.GetUnsignedIntegerField("rec.nHitTot");
        XCDFUnsignedIntegerField rec_nHit= inFile.GetUnsignedIntegerField("rec.nHit");
        XCDFUnsignedIntegerField rec_nHitSP10= inFile.GetUnsignedIntegerField("rec.nHitSP10");
        XCDFUnsignedIntegerField rec_nHitSP20= inFile.GetUnsignedIntegerField("rec.nHitSP20");
        XCDFUnsignedIntegerField rec_nTankAvail= inFile.GetUnsignedIntegerField("rec.nTankAvail");
        XCDFUnsignedIntegerField rec_nTankHitTot= inFile.GetUnsignedIntegerField("rec.nTankHitTot");
        XCDFUnsignedIntegerField rec_nTankHit= inFile.GetUnsignedIntegerField("rec.nTankHit");
        XCDFUnsignedIntegerField rec_windowHits= inFile.GetUnsignedIntegerField("rec.windowHits");
        XCDFUnsignedIntegerField rec_planeNDOF= inFile.GetUnsignedIntegerField("rec.planeNDOF");
        XCDFUnsignedIntegerField rec_mPFnHits= inFile.GetUnsignedIntegerField("rec.mPFnHits");
        XCDFUnsignedIntegerField rec_mPFp0nAssign= inFile.GetUnsignedIntegerField("rec.mPFp0nAssign");
        XCDFUnsignedIntegerField rec_mPFp1nAssign= inFile.GetUnsignedIntegerField("rec.mPFp1nAssign");
        XCDFUnsignedIntegerField rec_nHitMPF= inFile.GetUnsignedIntegerField("rec.nHitMPF");
        XCDFUnsignedIntegerField rec_coreFiduScale= inFile.GetUnsignedIntegerField("rec.coreFiduScale");
        XCDFFloatingPointField rec_zenithAngle= inFile.GetFloatingPointField("rec.zenithAngle");
        XCDFFloatingPointField rec_planeChi2= inFile.GetFloatingPointField("rec.planeChi2");
        XCDFFloatingPointField rec_fAnnulusCharge0= inFile.GetFloatingPointField("rec.fAnnulusCharge0");
        XCDFFloatingPointField rec_fAnnulusCharge1= inFile.GetFloatingPointField("rec.fAnnulusCharge1");
        XCDFFloatingPointField rec_fAnnulusCharge2= inFile.GetFloatingPointField("rec.fAnnulusCharge2");
        XCDFFloatingPointField rec_fAnnulusCharge3= inFile.GetFloatingPointField("rec.fAnnulusCharge3");
        XCDFFloatingPointField rec_fAnnulusCharge4= inFile.GetFloatingPointField("rec.fAnnulusCharge4");
        XCDFFloatingPointField rec_fAnnulusCharge5= inFile.GetFloatingPointField("rec.fAnnulusCharge5");
        XCDFFloatingPointField rec_fAnnulusCharge6= inFile.GetFloatingPointField("rec.fAnnulusCharge6");
        XCDFFloatingPointField rec_fAnnulusCharge7= inFile.GetFloatingPointField("rec.fAnnulusCharge7");
        XCDFFloatingPointField rec_fAnnulusCharge8= inFile.GetFloatingPointField("rec.fAnnulusCharge8");
        XCDFFloatingPointField rec_logMaxPE= inFile.GetFloatingPointField("rec.logMaxPE");
        XCDFFloatingPointField rec_logNPE= inFile.GetFloatingPointField("rec.logNPE");
        XCDFFloatingPointField rec_CxPE40= inFile.GetFloatingPointField("rec.CxPE40");
        XCDFFloatingPointField rec_logGP= inFile.GetFloatingPointField("rec.logGP");
        XCDFFloatingPointField rec_mPFp0Weight= inFile.GetFloatingPointField("rec.mPFp0Weight");
        XCDFFloatingPointField rec_mPFp1Weight= inFile.GetFloatingPointField("rec.mPFp1Weight");
        XCDFFloatingPointField rec_disMax= inFile.GetFloatingPointField("rec.disMax");
        XCDFFloatingPointField rec_TankLHR= inFile.GetFloatingPointField("rec.TankLHR");
        XCDFFloatingPointField rec_LHLatDistFitXmax= inFile.GetFloatingPointField("rec.LHLatDistFitXmax");
        XCDFFloatingPointField rec_LHLatDistFitEnergy= inFile.GetFloatingPointField("rec.LHLatDistFitEnergy");
        XCDFFloatingPointField rec_LHLatDistFitGoF= inFile.GetFloatingPointField("rec.LHLatDistFitGoF");
        //XCDFFloatingPointField mc_logEnergy= inFile.GetFloatingPointField("mc.logEnergy");
        
        std::set<std::string> fields;
        
        GetFieldNamesVisitor getFieldNamesVisitor(fields);
        inFile.ApplyFieldVisitor(getFieldNamesVisitor);
        
        SelectFieldVisitor selectFieldVisitor(inFile, fields, buffer);
        inFile.ApplyFieldVisitor(selectFieldVisitor);
        
        numevt = 0;
        while (inFile.Read()) {
            std::vector<double> inpparameters;
            inpparameters.push_back(123456);
            inpparameters.push_back(*rec_eventID);
            inpparameters.push_back(*rec_nChAvail);
            inpparameters.push_back(*rec_nHitTot);
            inpparameters.push_back(*rec_nHit);
            inpparameters.push_back(*rec_nHitSP10);
            inpparameters.push_back(*rec_nHitSP20);
            inpparameters.push_back(*rec_nTankAvail);
            inpparameters.push_back(*rec_nTankHitTot);
            inpparameters.push_back(*rec_nTankHit);
            inpparameters.push_back(*rec_windowHits);
            inpparameters.push_back(*rec_planeNDOF);
            inpparameters.push_back(*rec_mPFnHits);
            inpparameters.push_back(*rec_mPFp0nAssign);
            inpparameters.push_back(*rec_mPFp1nAssign);
            inpparameters.push_back(*rec_nHitMPF);
            inpparameters.push_back(*rec_coreFiduScale);
            inpparameters.push_back(*rec_zenithAngle);
            inpparameters.push_back(*rec_planeChi2);
            inpparameters.push_back(*rec_fAnnulusCharge0);
            inpparameters.push_back(*rec_fAnnulusCharge1);
            inpparameters.push_back(*rec_fAnnulusCharge2);
            inpparameters.push_back(*rec_fAnnulusCharge3);
            inpparameters.push_back(*rec_fAnnulusCharge4);
            inpparameters.push_back(*rec_fAnnulusCharge5);
            inpparameters.push_back(*rec_fAnnulusCharge6);
            inpparameters.push_back(*rec_fAnnulusCharge7);
            inpparameters.push_back(*rec_fAnnulusCharge8);
            inpparameters.push_back(*rec_logMaxPE);
            inpparameters.push_back(*rec_logNPE);
            inpparameters.push_back(*rec_CxPE40);
            inpparameters.push_back(*rec_logGP);
            inpparameters.push_back(*rec_mPFp0Weight);
            inpparameters.push_back(*rec_mPFp1Weight);
            inpparameters.push_back(*rec_disMax);
            inpparameters.push_back(*rec_TankLHR);
            inpparameters.push_back(*rec_LHLatDistFitXmax);
            inpparameters.push_back(*rec_LHLatDistFitEnergy);
            inpparameters.push_back(*rec_LHLatDistFitGoF);
            // Cargar capa 0
            prediction = nntf.Predict(nntf.ComputeScaling(inpparameters));
//            log_info ("IDevent: " << *rec_eventID <<", Predict: " <<  prediction << ", True: "<< *mc_logEnergy << ", difference: " << (prediction - *mc_logEnergy));
            tfout << prediction;
            buffer.CopyData();
            outFile.Write();
            numevt++;
        }
        log_info("Number of events in the file: " << numevt);
        for (
             std::vector<std::string>::const_iterator
             it  = inFile.CommentsBegin(),
             end = inFile.CommentsEnd();
             it != end;
             ++it
             ) outFile.AddComment(*it);
        
    }
    
    std::cout << "CODE END" << std::endl;
    return 0;
}
