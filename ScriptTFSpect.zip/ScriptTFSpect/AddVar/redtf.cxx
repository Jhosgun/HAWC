#include "redtf.h"
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include <iomanip>
#include <limits>
#include <hawcnest/Logging.h>
#include <string>

void redtf::ChargeScalingFile(const std::string& file_path) {
    std::ifstream file(file_path);
    std::string line;
    // Skip the header row
    std::getline(file, line);
    while (std::getline(file, line)) {
        std::vector<double> row;
        std::stringstream ss(line);
        std::string value;
        while (std::getline(ss, value, ',')) {
            row.push_back(std::stod(value));
        }
        medias_.push_back(row[0]);
        desviaciones_estandar_.push_back(row[1]);
    }
    log_info("scaling : " << medias_.size());
}

std::vector<double> redtf::ComputeScaling(const std::vector<double>& X) {
    std::vector<double> X_escalado(std::vector<double>(X.size()));
    for (size_t j = 0; j < X.size(); ++j) {
        X_escalado[j] = (X[j] - medias_[j]) / desviaciones_estandar_[j];
//        log_info( "Val [ " << j << " ] = " << X[j] << ", modi: " << X_escalado[j] << ", mean: " << medias_[j] << "std: " << desviaciones_estandar_[j]);
    }
    return X_escalado;
}

void redtf::ChargeWeightsFiles(int num_layers, const std::string& file_path) {
    std::string weights_file;
    std::string biases_file;
    num_layers_ = num_layers;
    for (int i = 0; i < num_layers_; i++ ){
        weights_file = file_path + "/layer_" + std::to_string(i) + "_weights_VF.csv";
        biases_file = file_path + "/layer_" + std::to_string(i) + "_biases_VF.csv";
        std::ifstream biases_stream(biases_file);
        std::ifstream weights_stream(weights_file);
        std::string line;
        // Cargar sesgos
        while (std::getline(biases_stream, line)) {
            biases_[i].push_back(std::stod(line));
        }
        while (std::getline(weights_stream, line)) {
            std::vector<double> row;
            std::stringstream ss(line);
            std::string value;
            while (std::getline(ss, value, ',')) {
                row.push_back(std::stod(value));
            }
            weights_[i].push_back(row);
        }
        log_info("LAYER : " << i << ", BIAS : " << biases_[i].size());
        log_info("LAYER : " << i << ", WEIGHT : " << weights_[i].size());
    }
}

std::vector<double> redtf::relu(const std::vector<double>& x) {
    std::vector<double> result(x.size());
    std::transform(x.begin(), x.end(), result.begin(), [](double value) {
        return std::max(0.0, value);
    });
    return result;
}

double redtf::Predict(const std::vector<double>& X) {
    double outputs=-10;
    std::vector<double> output = X;
    for (int i = 0; i < num_layers_; i++) {
        std::vector<double> new_output(biases_[i].size());
        for (size_t j = 0; j < biases_[i].size(); j++) {
            double sum = 0.0;
            for (size_t k = 0; k < output.size(); k++) {
                sum += output[k] * weights_[i][k][j];
            }
            new_output[j] = sum + biases_[i][j];
        }
        output = (i < num_layers_ - 1) ? relu(new_output) : new_output;
    }
//    log_info("SALIDA : "<< output[0]);
    outputs=output[0];
    return outputs;
}
