#!/bin/bash
#SBATCH --mem=500mb
#SBATCH -t 0-10:00:00

source ${HOME}/.bashrc
hawc_intsw
echo " * * * * Add output of the Neural Network Trained * * * * "
INFILE=$1
if [ -z $INFILE ]
then
    echo "Check your parameters, this directory does not exist: "${INFILE}
    exit 1
fi
CONFIGDIR=$2
if [ -z $CONFIGDIR ]
then
    echo "Check your parameters, this directory does not exist: "${CONFIGDIR}
    exit 1
fi
OUTDIR=$3
mkdir -vp ${OUTDIR}
DIRSCRIPT=$4

MAKEROOT=$5
if [ -z $MAKEROOT ]
then
    MAKEROOT="1"
fi
##############################
echo "************************"
echo "Directories:"
echo "1.INFILE    : "$INFILE
echo "2.CONFIGDIR : "$CONFIGDIR
echo "3.OUTDIR    : "$OUTDIR
echo "4.DIRSCRIPT : "$DIRSCRIPT
echo "5.MAKEROOT  : "$MAKEROOT
echo "************************"
##############################
cd $HOME
echo $HOME


echo "ADDING the NEURAL NETWORK OUTPUT to the file "
TAG=`basename $INFILE`
OURXCDFFILE=${OUTDIR}/${TAG}
echo "The new files is: "${OURXCDFFILE}
SCRIPT=${DIRSCRIPT}/add-TFout

echo "--------------------------------"
echo "PARAMETER OF : "${SCRIPT}
echo "INFILE       : "$INFILE
echo "OURXCDFFILE  : "$OURXCDFFILE
echo "CONFIGDIR    : "$CONFIGDIR
echo "--------------------------------"
${SCRIPT} --in-files ${INFILE} -o ${OURXCDFFILE} --configdir ${CONFIGDIR}

if [ $MAKEROOT == "1" ]
then
    TAG=`basename $OURXCDFFILE .xcd`
    OUTPUTROOT=${OUTDIR}/${TAG}".root"
    XCDFROOT=${SOFTWARE_BASE}/hawc_aerie/aerie/install/bin/xcdf-root
    echo "--------------------------------"
    echo "PARAMETER OF :"${XCDFROOT}
    echo "convert to root files"
    echo "INPUT: "$OURXCDFFILE
    echo "OUTPUT: "$OUTPUTROOT
    echo "--------------------------------"
    $XCDFROOT --timelog -o $OUTPUTROOT --input $OURXCDFFILE --nocomment
fi

echo "fin,end"
