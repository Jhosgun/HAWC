#!/bin/bash
#SBATCH --mem=500mb
#SBATCH -t 0-30:00:00

source ${HOME}/.bashrc
hawc_intsw
echo " * * * * Add output to real data of the Neural Network Trained * * * * "
INFILE=$1
if [ -z $INFILE ]
then
    echo "Check your parameters, this directory does not exist: "${INFILE}
    exit 1
fi
CONFIGDIR=$2
if [ -z $CONFIGDIR ]
then
    echo "Check your parameters, this directory does not exist: "${CONFIGDIR}
    exit 1
fi
OUTDIR=$3
mkdir -vp ${OUTDIR}
DIRSCRIPT=$4

MAKEROOT=$5
if [ -z $MAKEROOT ]
then
    MAKEROOT="1"
fi
##############################
echo "************************"
echo "Directories:"
echo "1.INFILE    : "$INFILE
echo "2.CONFIGDIR : "$CONFIGDIR
echo "3.OUTDIR    : "$OUTDIR
echo "4.DIRSCRIPT : "$DIRSCRIPT
echo "5.MAKEROOT  : "$MAKEROOT
echo "************************"
##############################
cd $HOME
echo $HOME

echo "ADDING the NEURAL NETWORK OUTPUT to the file "
SCRIPT=${DIRSCRIPT}/add-TFout

INFILES=${INFILE}/*xcd
ls -hl ${INFILES}
echo `ls -l ${INFILES} | wc -l`
LIST=""
TAG=`basename $INFILE`
OUTSUBRUN=${OUTDIR}/${TAG}
mkdir -vp $OUTSUBRUN

for infile in ${INFILES}
do
    TAG=`basename $infile`
    OURXCDFFILE=${OUTSUBRUN}/${TAG}
    if [ -f ${OURXCDFFILE} ]
    then
        echo "FILE "${OURXCDFFILE}" exist, so we dont add variable"
    else
        echo "--------------------------------"
        echo "PARAMETER OF :"${SCRIPT}
        echo "INFILE       : "$infile
        echo "OURXCDFFILE  : "$OURXCDFFILE
        echo "CONFIGDIR   : "$CONFIGDIR
        ${SCRIPT} --in-files ${infile} -o ${OURXCDFFILE} --configdir ${CONFIGDIR}
	echo "--------------------------------"
    fi
    LIST=${LIST}" "${OURXCDFFILE}
done

XCDFAPP=${SOFTWARE_BASE}/hawc_aerie/externals/External/xcdf/3.00.03/bin/xcdf
TAG=`basename $INFILE`
XCDFFILEDIR=${OUTDIR}/combined
mkdir -vp ${XCDFFILEDIR}
XCDFFILE=${XCDFFILEDIR}/$TAG.xcd
if [ -f ${XCDFFILE} ]
then
    echo "FILE "${XCDFFILE}" exist, so we dont combine files"
else
    echo "--------------------------------"
    echo "PARAMETER OF :"${XCDFAPP}
    echo "INFILE	   : "${LIST}
    echo "OURXCDFFILE  : "${XCDFFILE}
    ${XCDFAPP} select "1" -o ${XCDFFILE} ${LIST}
    echo "--------------------------------"
fi
if [ $MAKEROOT == "1" ]
then
    TAG=`basename $XCDFFILE .xcd`
    OUTPUTROOT=${XCDFFILEDIR}/${TAG}"_V2.root"
    XCDFROOT=${SOFTWARE_BASE}/hawc_aerie/aerie/install/bin/xcdf-root
    echo "--------------------------------"
    echo "PARAMETER OF :"${XCDFROOT}
    echo "convert to root files"
    echo "INPUT: "$XCDFFILE
    echo "OUTPUT: "$OUTPUTROOT
    echo "--------------------------------"
    if [ -f ${OUTPUTROOT} ]
    then
        echo "FILE "${OUTPUTROOT}" exist, so we dont combine files"
    else
        $XCDFROOT --timelog -o $OUTPUTROOT --input $XCDFFILE --nocomment
    fi
fi
echo "fin,end"
