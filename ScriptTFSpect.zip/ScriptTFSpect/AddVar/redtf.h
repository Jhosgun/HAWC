#ifndef REDTF_H
#define REDTF_H
#include <fstream>
#include <sstream>
#include <algorithm>
#include <stdexcept>
#include <iomanip>
#include <limits>
#include <hawcnest/Logging.h>
#include <string>

class redtf{
    std::vector<double> medias_, desviaciones_estandar_;
    std::vector<std::vector<double>> weights_[10];
    std::vector<double> biases_[10];
    int num_layers_;
public:
    redtf(){ log_info( "Constructor"); }
    void ChargeScalingFile(const std::string& file_path);
    std::vector<double> ComputeScaling(const std::vector<double>& X);
    void ChargeWeightsFiles(int num_layers, const std::string& file_path);
    std::vector<double> relu(const std::vector<double>& x);
    double Predict(const std::vector<double>& X);
    
};



#endif
