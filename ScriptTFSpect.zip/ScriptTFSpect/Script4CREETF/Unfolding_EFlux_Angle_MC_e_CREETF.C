/**
 * @Author: J.A.M.S. <jorge-moralesas>
 * @Date:   2020-04-24T02:03:26-05:00
 * @Email:  jorge.morales@umich.mx
 * @Last modified by:   jorge-moralesas
 * @Last modified time: 2024-03-19T17:05:19-06:00
 */



{
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                           Clean Memory

    gDirectory->DeleteAll();
    gROOT->Reset();
    gROOT->cd();


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                               Load cuts

    gROOT->ProcessLine(".x ./MyCuts_DQB_paper_CREETF.C");


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                               Print information
    cout << endl << "+++++++++++++++++++++++ MC data +++++++++++++++++++++++++";
    cout << endl;


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Define variables

    //Zenith Angle and Primary type
    Int_t    ncutZenith = 3;
    Int_t    ncutMass   = 0;
    Int_t    nUnfolding = 0;
    Int_t    nIterations = 1;
    Int_t    nCutAge_vs_logEnergy = 0;
    Int_t    ncutMassToReconstruct = 0;

    //Factor of weight for events
    Double_t WeightFactor = 32168.625;

    //Energy spectrum
    Int_t    ibinx = 0, nbinx = 22;
    Double_t Gamma_Index = 2.6;
    Double_t E_Set[50], logE_Set[50];
    Double_t NeventsE_Set[50], DNeventsE_Set[50];
    Double_t DlogE_Set[50], DlogEhalf_Set[50], DE_Set[50], DEhalf_Set[50];
    Double_t FluxE_Set [50], DFluxE_Set [50];
    Double_t FluxE1_Set[50], DFluxE1_Set[50];
    Double_t FluxEGamma_Set[50], DFluxEGamma_Set[50];
    Double_t Aream2 = 22e3*pow(1,2.0), DtSec =  1.0*WeightFactor;
    Double_t  logEGeV_minimum = 2.0;
    Double_t  logEGeV_maximum = 6.4;

    //Variable for Cuts
    TCut MyCuts;

    //List
    Int_t   nev_List, iev_List, iev_Root;
    TEntryList *temp_List = NULL;
    TEntryList *ListALL   = NULL;
    Char_t      nameListAll[30];


    //Classify event according to mass composition
    Long64_t Classififed_Mass = 0;


    //Plotting Style
    Int_t  colorMark[12] = { 1, 2, 4, 8, 6, 41,50,25,28,36, 3, 5};
    Int_t  styleMark[12] = {20,22,25,26,24,27,20,22,25,26, 20, 20};


    //Weight
    Double_t Weight_TOTAL = 1.0;

    Char_t  DIROUT[60];
    sprintf(DIROUT, "CREETF_JCCUTS");
    //sprintf(DIROUT, "CREETF_QC");
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                      Choose parameters

    cout << endl << "Composition model based on fit to Exp. data"<< endl;
    ncutMass  = 0;

    cout << endl << "Unfolding of mass group energy spectra using CREAM-II model"<< endl;
    cout << endl << "0) No cut   1) Light (cut at He)  2) Light (cut mid He&C)  3) Light (cut at C)   4) H (cut at H)  5) Z>1 (cut at He)  6) Z>2 (cut mid He&C): ";
    cin  >> nCutAge_vs_logEnergy;

    Char_t  nameFile_nCutAge_vs_logEnergy[60];
    Char_t  namePlot_nCutAge_vs_logEnergy[60];
    
    switch(nCutAge_vs_logEnergy)
    {
        case 0:
            sprintf(nameFile_nCutAge_vs_logEnergy, "noMassCut");
            sprintf(namePlot_nCutAge_vs_logEnergy, "All Nuclei");
            ncutMassToReconstruct = 0;
            break;
        case 1:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 2:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 3:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 4:
            sprintf(nameFile_nCutAge_vs_logEnergy, "H_at_H");
            sprintf(namePlot_nCutAge_vs_logEnergy, "H");
            ncutMassToReconstruct = 1;
            break;
        case 5:
            sprintf(nameFile_nCutAge_vs_logEnergy, "Heavy_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 11;
            break;
        case 6:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
    }

   //cout << endl << "Select the zenith angle interval (deg)";
   cout << endl << "The zenith angle interval (deg)";
   cout << endl << "0)[   0,16.7] ";
   //cin  >> ncutZenith;
    ncutZenith=0;


    cout << endl << "Apply unfolding procedure to all-particle spectrum [no(0)  yes(1)] :";
    cin  >> nUnfolding;


    if(nUnfolding == 1)
    {
        cout << endl << "How many iterations? ";
        cin  >> nIterations;

        cout << endl << "Mass To Reconstruct";
        cout << endl << legendcutMass[ncutMassToReconstruct] << endl;
    }


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Define Canvas

    cFlux = new TCanvas("cFlux","MC Rec Energy spectrum",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cFlux->Clear();
    cFlux->SetGridx(0);
    cFlux->SetGridy(0);
    cFlux->SetBorderMode(0);


    cFluxE1 = new TCanvas("cFluxE1","MC Rec Energy spectrum x E",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cFluxE1->Clear();
    cFluxE1->SetGridx(0);
    cFluxE1->SetGridy(0);
    cFluxE1->SetBorderMode(0);


    cFluxEGamma = new TCanvas("cFluxEGamma","MC Rec Energy spectrum x E**Gamma",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cFluxEGamma->Clear();
    cFluxEGamma->SetGridx(0);
    cFluxEGamma->SetGridy(0);
    cFluxEGamma->SetBorderMode(0);


    cResponseMatrix = new TCanvas("cResponseMatrix","MC Rec Energy spectrum x E**Gamma",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(0);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cResponseMatrix->Clear();
    cResponseMatrix->SetGridx(0);
    cResponseMatrix->SetGridy(0);
    cResponseMatrix->SetBorderMode(0);




//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Define Histograms

    TH1D   *hFlux[maxcutMass];
    Char_t  namehFlux[maxcutMass][30];
    for(icutMass = 0; icutMass < maxcutMass; icutMass++)
    {
      sprintf(namehFlux[icutMass], "hFlux%d", icutMass);
      hFlux[icutMass] = new TH1D(namehFlux[icutMass], namehFlux[icutMass], nbinx, logEGeV_minimum, logEGeV_maximum);
      hFlux[icutMass]->Sumw2();
    }

    TGraphErrors *FluxvslogE     [maxcutMass];
    TGraphErrors *FluxvslogE1    [maxcutMass];
    TGraphErrors *FluxvslogEGamma[maxcutMass];
    TGraphErrors *FluxvsEGamma   [maxcutMass];

    TH2D *h2DResponseMatrixRecvsTrue_mixed = new TH2D("h2DResponseMatrixRecvsTrue_mixed", "h2DResponseMatrixRecvsTrue_mixed", nbinx, logEGeV_minimum, logEGeV_maximum,  nbinx, logEGeV_minimum, logEGeV_maximum);
    h2DResponseMatrixRecvsTrue_mixed->Sumw2();

    TH1D   *hFlux_nTrue[maxcutMass];
    Char_t  namehFlux_nTrue[maxcutMass][30];
    for(icutMass = 0; icutMass < maxcutMass; icutMass++)
    {
        sprintf(namehFlux_nTrue[icutMass], "hFlux_nTrue%d", icutMass);
        hFlux_nTrue[icutMass] = new TH1D(namehFlux_nTrue[icutMass], namehFlux_nTrue[icutMass], nbinx, logEGeV_minimum, logEGeV_maximum);
    }

    TH1D   *hFlux_nTrue2[maxcutMass];
    Char_t  namehFlux_nTrue2[maxcutMass][30];
    for(icutMass = 0; icutMass < maxcutMass; icutMass++)
    {
        sprintf(namehFlux_nTrue2[icutMass], "hFlux_nTrue2%d", icutMass);
        hFlux_nTrue2[icutMass] = new TH1D(namehFlux_nTrue2[icutMass], namehFlux_nTrue2[icutMass], nbinx, logEGeV_minimum, logEGeV_maximum);
    }

    TF1 *powerlaw = new TF1("powerlaw", "[0]*pow(10.0, x)**[1]", logEGeV_minimum,logEGeV_maximum);
    powerlaw->SetParameters(2e-16, -1.5);

    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                         Load Data

    //Internal Variables
    ULong64_t mc_corsikaParticleId_Load;
    Double_t  mc_logEnergy_Load;
    Double_t  mc_radiusWeight_Load;
    Double_t  mc_coreR_Load;
    Double_t  mc_eventWeight_Load;

    Double_t  sweets_IWgt_Load;

    Double_t   rec_protonlheEnergy_Load;
    ULong64_t  rec_nHit_Load;
    Double_t   rec_coreFitUnc_Load;
    ULong64_t  rec_coreFitStatus_Load;
    ULong64_t  rec_angleFitStatus_Load;
    Double_t   rec_zenithAngle_Load;
    ULong64_t  rec_coreFiduScale_Load;
    Double_t   rec_LDFAge_Load;
    ULong64_t  rec_nChAvail_Load;


    //Open ROOT file
    TChain *chain_new = new TChain("XCDF", "");
    // pass5.1 con Modelo 2
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_proton_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_helium_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_carbon_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_oxygen_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_neon_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_magnesium_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_silicon_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_iron_rec.root");
    
    /*
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_proton_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_helium_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_carbon_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_oxygen_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_neon_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_magnesium_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_silicon_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_iron_daq.root");



    TChain *chain2_new = new TChain("XCDF", "");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_proton_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_helium_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_carbon_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_oxygen_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_neon_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_magnesium_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_silicon_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_iron_new_sweet.root");
    chain_new->AddFriend(chain2_new);
*/

   //Disable all branches
   chain_new->SetBranchStatus("*",0);

   //Set Status of Branch
   chain_new->SetBranchStatus("mc.corsikaParticleId",1);
   chain_new->SetBranchStatus("mc.logEnergy",1);

   //chain_new->SetBranchStatus("sweets.IWgt.new",1);
    chain_new->SetBranchStatus("sweets.IWgt",1);

   chain_new->SetBranchStatus("rec.tfout",1);
   chain_new->SetBranchStatus("rec.nHit",1);
   chain_new->SetBranchStatus("rec.coreFitUnc",1);
   chain_new->SetBranchStatus("rec.coreFitStatus",1);
   chain_new->SetBranchStatus("rec.angleFitStatus",1);
   chain_new->SetBranchStatus("rec.zenithAngle",1);
   chain_new->SetBranchStatus("rec.coreFiduScale",1);
   chain_new->SetBranchStatus("rec.LDFAge",1);
   chain_new->SetBranchStatus("rec.nChAvail",1);

   chain_new->SetBranchStatus("rec.CxPE40XnCh",1);
   chain_new->SetBranchStatus("rec.CxPE40",1);
   chain_new->SetBranchStatus("rec.logCoreAmplitude",1);


   //Direction of branch to internal variable
   chain_new->SetBranchAddress("mc.corsikaParticleId",&mc_corsikaParticleId_Load);
   chain_new->SetBranchAddress("mc.logEnergy",&mc_logEnergy_Load);

   //chain_new->SetBranchAddress("sweets.IWgt.new",&sweets_IWgt_Load);
    chain_new->SetBranchAddress("sweets.IWgt",&sweets_IWgt_Load);

   chain_new->SetBranchAddress("rec.tfout",&rec_protonlheEnergy_Load);
   chain_new->SetBranchAddress("rec.nHit",&rec_nHit_Load);
   chain_new->SetBranchAddress("rec.coreFitUnc",&rec_coreFitUnc_Load);
   chain_new->SetBranchAddress("rec.coreFitStatus",&rec_coreFitStatus_Load);
   chain_new->SetBranchAddress("rec.angleFitStatus",&rec_angleFitStatus_Load);
   chain_new->SetBranchAddress("rec.zenithAngle",&rec_zenithAngle_Load);
   chain_new->SetBranchAddress("rec.coreFiduScale",&rec_coreFiduScale_Load);
   chain_new->SetBranchAddress("rec.LDFAge",&rec_LDFAge_Load);
   chain_new->SetBranchAddress("rec.nChAvail",&rec_nChAvail_Load);



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                  Define mass separation cuts

   //ONLY USE FOR ZENITH BIN NUMBER 0
   if(ncutZenith == 0)
    {
      cout << endl << "@ Separation using Age vs logEnergy plot for zenith bin number 0" << endl;
      TFile file_cut_H_He("~/HAWC/Analisis/tests/Age/v6/Plots_Age_Zeg0_MC_Fit_H_He_DQB.root");
      TFile file_cut_He_C("~/HAWC/Analisis/tests/Age/v6/Plots_Age_Zeg0_MC_Fit_He_C_DQB.root");
    }
   file_cut_H_He.cd();
   cut_H = (TF1*)gDirectory->Get("lineAge_vs_protonlheEnergy_Zeg0_Mass1");
   file_cut_He_C.cd();
   cut_He = (TF1*)gDirectory->Get("lineAge_vs_protonlheEnergy_Zeg0_Mass2");
   cut_C  = (TF1*)gDirectory->Get("lineAge_vs_protonlheEnergy_Zeg0_Mass3");


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                 Select Palette color
    //gStyle->SetPalette(52);


    const Int_t NRGBs=9;
    const Int_t NCont=299;

    //BIRD
     Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
     Double_t red[NRGBs]={0.2082, 0.0592, 0.0780, 0.0232, 0.1802, 0.5301, 0.8186, 0.9956, 0.9764};
     Double_t green[NRGBs]={0.1664, 0.3599, 0.5041, 0.6419, 0.7178, 0.7492, 0.7328, 0.7862, 0.9832};
     Double_t blue[NRGBs]={0.5293, 0.8684, 0.8385, 0.7914, 0.6425, 0.4662, 0.3499, 0.1968, 0.0539};

    //MINT
    //Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
    //Double_t red[NRGBs]={105./255., 106./255., 122./255., 143./255., 159./255., 172./255., 176./255., 181./255., 207./255.};
    //Double_t green[NRGBs]={252./255., 197./255., 194./255., 187./255., 174./255., 162./255., 153./255., 136./255., 125./255.};
    //Double_t blue[NRGBs]={146./255., 133./255., 144./255., 155./255., 163./255., 167./255., 166./255., 162./255., 174./255.};

    //Cherry
    //Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
    //Double_t red[NRGBs]={37./255., 102./255., 157./255., 188./255., 196./255., 214./255., 223./255., 235./255., 251./255.};
    //Double_t green[NRGBs]={37./255.,  29./255.,  25./255.,  37./255.,  67./255.,  91./255., 132./255., 185./255., 251./255.};
    //Double_t blue[NRGBs]={37./255.,  32./255.,  33./255.,  45./255.,  66./255.,  98./255., 137./255., 187./255., 251./255.};

    //Pastel
    //Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
    //Double_t red[NRGBs]={180./255., 190./255., 209./255., 223./255., 204./255., 228./255., 205./255., 152./255.,  91./255.};
    //Double_t green[NRGBs]={93./255., 125./255., 147./255., 172./255., 181./255., 224./255., 233./255., 198./255., 158./255.};
    //Double_t blue[NRGBs]={236./255., 218./255., 160./255., 133./255., 114./255., 132./255., 162./255., 220./255., 218./255.};

    //Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
    //Double_t red[NRGBs]={171./255., 141./255., 145./255., 152./255., 154./255., 159./255., 163./255., 158./255., 177./255.};
    //Double_t green[NRGBs]={236./255., 143./255., 100./255.,  63./255.,  53./255.,  55./255.,  44./255.,  31./255.,   6./255.};
    //Double_t blue[NRGBs]={59./255.,  48./255.,  46./255.,  44./255.,  42./255.,  54./255.,  82./255., 112./255., 179./255.};

    //Custom1: Green
    //Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
    //Double_t red[NRGBs]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //Double_t green[NRGBs]={252./255., 197./255., 194./255., 187./255., 174./255., 162./255., 153./255., 136./255., 125./255.};
    //Double_t blue[NRGBs]={236./255., 218./255., 160./255., 133./255., 114./255., 132./255., 162./255., 220./255., 218./255.};

    //Custom2: Green
    //Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
    //Double_t red[NRGBs]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //Double_t green[NRGBs]={119./255., 134./255., 153./255., 169./255., 189./255., 197./255., 204./255., 217./255., 252./255.};
    //Double_t blue[NRGBs]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 119./255.};

    //Custom3: Blue
    //Double_t stops[NRGBs]={0.0000, 0.1250, 0.2500, 0.3750, 0.5000, 0.6250, 0.7500, 0.8750, 1.0000};
    //Double_t red[NRGBs]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0};
    //Double_t green[NRGBs]={0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 119./255.};
    //Double_t blue[NRGBs]={119./255., 134./255., 153./255., 169./255., 189./255., 197./255., 204./255., 217./255., 252./255.};

    TColor::CreateGradientColorTable(NRGBs,stops,red,green,blue,NCont);
    gStyle->SetNumberContours(NCont);

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                 Select and Work out data

    //Generate List with selected data
    //Original Jorge
    //MyCuts = (mycutMass[0] && mycutZenith[ncutZenith] && mycutcoreFiduScale && mycutCxPE40  && mycutlogEvsZenith[ncutZenith]);
    // Quality CUTS
    //MyCuts = (mycutMass[0] && mycutZenith[ncutZenith] && mycutlogEvsZenith[ncutZenith] && mycutcoreFiduScale && mycutnHit && mycutcoreFitStatus && mycutangleFitStatus);
    //JC CUTS
    MyCuts = (mycutMass[0] && mycutZenith[ncutZenith] && mycutlogEvsZenith[ncutZenith] && mycutcoreFiduScale && mycutCxPE40 && mycutnHit && mycutcoreFitStatus && mycutangleFitStatus);
    cout << "LOS CORTES: " << MyCuts.Print() << endl;
    
    chain_new->Draw(">>Save_List", MyCuts, "entrylist");
    temp_List  = (TEntryList*)gDirectory->Get("Save_List");
    ListAll    = (TEntryList*)temp_List.Clone();
    sprintf(nameListAll, "ListAll");
    ListAll->SetName(nameListAll);

    //Upload list
    chain_new->SetEntryList(ListAll);
    chain_new->Draw("mc.logEnergy");

    //Read number of events
    nev_List = (Int_t)chain_new->GetSelectedRows();


    //Read each event
    gROOT->cd();
    for(iev_List = 0; iev_List < nev_List; iev_List++)
    {
        //Get Event and load values of branches
        iev_Root = chain_new->GetEntryNumber(iev_List);
        chain_new->GetEntry(iev_Root);
        Weight_TOTAL = sweets_IWgt_Load*WeightFactor;

        //Separation criteria
        Int_t nPass = 0;
        switch(nCutAge_vs_logEnergy)
        {
            case 0:
                nPass = 1;
                break;
            case 1:
                if(rec_LDFAge_Load < cut_He.Eval((rec_protonlheEnergy_Load))) nPass = 1;
                break;
            case 2:
                if(rec_LDFAge_Load <  (cut_He.Eval((rec_protonlheEnergy_Load)) + cut_C.Eval((rec_protonlheEnergy_Load)))/2.0) nPass = 1;
                break;
            case 3:
                if(rec_LDFAge_Load < cut_C.Eval((rec_protonlheEnergy_Load))) nPass = 1;
                break;
            case 4:
                if(rec_LDFAge_Load < cut_H.Eval((rec_protonlheEnergy_Load))) nPass = 1;
                break;
            case 5:
                if(rec_LDFAge_Load > cut_He.Eval((rec_protonlheEnergy_Load))) nPass = 1;
                break;
            case 6:
                if(rec_LDFAge_Load >=  (cut_He.Eval(rec_protonlheEnergy_Load) + cut_C.Eval(rec_protonlheEnergy_Load))/2.0) nPass = 1;
                break;
        }

        if(nPass == 1)
        {

	  //Response matrix based on CREAM-II
	  h2DResponseMatrixRecvsTrue_mixed->Fill(mc_logEnergy_Load, (rec_protonlheEnergy_Load),  Weight_TOTAL);
	  hFlux[ncutMass]->Fill((rec_protonlheEnergy_Load), Weight_TOTAL);
    //hFlux[ncutMass]->Fill(mc_logEnergy_Load, Weight_TOTAL);
	  hFlux_nTrue [ncutMass]->Fill(mc_logEnergy_Load, Weight_TOTAL);
      hFlux_nTrue2[ncutMass]->Fill(mc_logEnergy_Load, Weight_TOTAL**2);
        }
    }


    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    //Get SUM_{j=1,N} n(i,j) for nomalization of response matrix
    Double_t Sum_rec[nbinx] = {0.0};
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        Sum_rec[ibinx] = h2DResponseMatrixRecvsTrue_mixed->Integral(ibinx+1,ibinx+1,1,nbinx);
    }


    //Normalize response matrix p(i,j) = n(i,j) / SUM_{j=1,N} n(i,j).
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        if(Sum_rec[ibinx] > 0)
        {
            for(Int_t ibinx_rec = 0; ibinx_rec < nbinx; ibinx_rec++)
            {
              Double_t p_tr_rec = h2DResponseMatrixRecvsTrue_mixed->GetBinContent(ibinx+1,ibinx_rec+1)/Sum_rec[ibinx];
              h2DResponseMatrixRecvsTrue_mixed->SetBinContent(ibinx+1,ibinx_rec+1, p_tr_rec);
            }
        }
    }


    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    if(nUnfolding == 1)
    {

       //Read Efficiency plot for Unfolding
       Char_t name_ROOTFILE_EfficiencyvsTrueEnergy [300];
       Char_t name_gEfficiencyvsTrueEnergy         [300];

       sprintf(name_ROOTFILE_EfficiencyvsTrueEnergy, "%s/newEA_Plot_EffArea_Zeg%d_Mass%d_Cut_%s_Bin%d_MC_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);


       TFile ROOTFile_EfficiencyvsTrueEnergy(name_ROOTFILE_EfficiencyvsTrueEnergy);
       sprintf(name_gEfficiencyvsTrueEnergy, "gEffective_Area_m2_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
       gEfficiencyvsTrueEnergy = (TGraphErrors*)gDirectory->Get(name_gEfficiencyvsTrueEnergy);
       hFluxunfold     =  (TH1D*)hFlux_nTrue[ncutMass]; // Para usar Bayesv4 descomentar esta línea



        //gROOT->ProcessLine(".L ~/HAWC/Analisis/tests/lib/Subroutine_Bayesian_plus_efficiency.c");
        //gROOT->ProcessLine(".L ./Lib/Subroutine_Bayesian_plus_efficiency_nosmoothroot_v4.c");
        gROOT->ProcessLine(".L ../Lib/smoothing_v4.c");
        //hFluxunfold = new TH1D("hFluxunfold","hFluxunfold", nbinx, logEGeV_minimum, logEGeV_maximum);


        //Unfolding(nIterations, hFlux[ncutMass], h2DResponseMatrixRecvsTrue_mixed, hFluxunfold, gEfficiencyvsTrueEnergy);

        for(ibinx = 0; ibinx < nbinx; ibinx++)
        {
            hFlux[ncutMass]->SetBinContent(ibinx+1, hFluxunfold->GetBinContent(ibinx+1));
        }



    }//End unfolding


    //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    //Energy spectrum
      for(ibinx = 0; ibinx < nbinx; ibinx++)
      {
    	//Fill E spectra
        logE_Set      [ibinx] = hFlux[ncutMass]->GetBinCenter(ibinx+1);
        E_Set         [ibinx] =  pow(10, logE_Set[ibinx]);
        DlogE_Set     [ibinx] = hFlux[ncutMass]->GetBinWidth (ibinx+1);
        NeventsE_Set  [ibinx] = hFlux[ncutMass]->GetBinContent(ibinx+1);
        DE_Set        [ibinx] =  pow(10, logE_Set[ibinx] + DlogE_Set[ibinx]/2)
                                -pow(10, logE_Set[ibinx] - DlogE_Set[ibinx]/2);
        DNeventsE_Set [ibinx] =  0.0;

        //Efficiency correction
        Double_t Eff = 1.0;
        if(nUnfolding == 1)
        {
           if(logE_Set[ibinx] >= 6.0)  { Eff = gEfficiencyvsTrueEnergy->Eval(logE_Set[ibinx]);}
           else                        { Eff = gEfficiencyvsTrueEnergy->Eval(logE_Set[ibinx]);}
           if(Eff == 0) {Eff = 1.0;NeventsE_Set[ibinx] = 0.0;}
        }

        //Muon number spectrum  in units of m^-2 s^-1 sr^-1
        FluxE_Set    [ibinx]  =   NeventsE_Set[ibinx]/DE_Set[ibinx];
        if(nUnfolding == 1)
        {
          FluxE_Set    [ibinx]  =   FluxE_Set[ibinx]/(DOmegaSr[ncutZenith]*DtSec*Eff);
          DFluxE_Set   [ibinx]  =   sqrt(NeventsE_Set[ibinx])/DE_Set[ibinx];
          DFluxE_Set   [ibinx]  =   DFluxE_Set[ibinx]/(DOmegaSr[ncutZenith]*DtSec*Eff);
        }
        else
        {
            FluxE_Set    [ibinx]  =   FluxE_Set[ibinx]/(Aream2*DOmegaSrCosef[ncutZenith]*DtSec*Eff);
            DFluxE_Set   [ibinx]  =   sqrt(NeventsE_Set[ibinx])/DE_Set[ibinx];
            DFluxE_Set   [ibinx]  =   DFluxE_Set[ibinx]/(Aream2*DOmegaSrCosef[ncutZenith]*DtSec*Eff);
        }

        DlogEhalf_Set[ibinx]  =   DlogE_Set[ibinx]*0.0/2.0;
        DEhalf_Set   [ibinx]  =   0.0;

        //Muon number spectrum  x Nmu in units of m^-2 s^-1 sr^-1
        FluxE1_Set  [ibinx]  =   FluxE_Set[ibinx]*E_Set[ibinx];
        DFluxE1_Set [ibinx]  =   DFluxE_Set[ibinx]*E_Set[ibinx];

        //Muon number spectrum  x Nmu in units of m^-2 s^-1 sr^-1
        FluxEGamma_Set [ibinx]=  FluxE_Set[ibinx] *pow(E_Set[ibinx], Gamma_Index);
        DFluxEGamma_Set[ibinx]=  DFluxE_Set[ibinx]*pow(E_Set[ibinx], Gamma_Index);
      }
      FluxvslogE     [ncutMass] = new TGraphErrors(nbinx, logE_Set, FluxE_Set, DlogEhalf_Set, DFluxE_Set);
      FluxvslogE1    [ncutMass] = new TGraphErrors(nbinx, logE_Set, FluxE1_Set, DlogEhalf_Set, DFluxE1_Set);
      FluxvslogEGamma[ncutMass] = new TGraphErrors(nbinx, logE_Set, FluxEGamma_Set, DlogEhalf_Set, DFluxEGamma_Set);
      FluxvsEGamma   [ncutMass] = new TGraphErrors(nbinx, E_Set, FluxEGamma_Set, DEhalf_Set, DFluxEGamma_Set);



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                       Plot data


      cFlux->cd();
      FluxvslogE[ncutMass]->SetTitle(0);
      FluxvslogE[ncutMass]->SetMaximum(1e-3);
      FluxvslogE[ncutMass]->SetMinimum(1e-15);
      FluxvslogE[ncutMass]->SetMarkerStyle(20);
      FluxvslogE[ncutMass]->SetMarkerColor(colorMark[ncutMass]);
      FluxvslogE[ncutMass]->SetLineColor(colorMark[ncutMass]);
      FluxvslogE[ncutMass]->GetXaxis()->SetTitle("log_{10}(E/GeV)");
      FluxvslogE[ncutMass]->GetYaxis()->SetTitle("d#Phi/dE [m^{-2} s^{-1} sr^{-1} GeV^{-1}]");
      FluxvslogE[ncutMass]->GetXaxis()->SetTitleSize(0.05);
      FluxvslogE[ncutMass]->GetYaxis()->SetTitleSize(0.05);
      FluxvslogE[ncutMass]->Draw("AP");
      powerlaw->SetParameters(1e7, -1.5);
      //FluxvslogE[ncutMass]->Fit("powerlaw","+","",4.5,5.5);



      cFluxE1->cd();
      FluxvslogE1[ncutMass]->SetTitle(0);
      FluxvslogE1[ncutMass]->SetMaximum(1);
      FluxvslogE1[ncutMass]->SetMinimum(1e-9);
      FluxvslogE1[ncutMass]->SetMarkerStyle(20);
      FluxvslogE1[ncutMass]->SetMarkerColor(colorMark[ncutMass]);
      FluxvslogE1[ncutMass]->SetLineColor(colorMark[ncutMass]);
      FluxvslogE1[ncutMass]->GetXaxis()->SetTitle("log_{10}(E/GeV)");
      FluxvslogE1[ncutMass]->GetYaxis()->SetTitle("E d#Phi/dE [m^{-2}  s^{-1} sr^{-1}]");
      FluxvslogE1[ncutMass]->GetXaxis()->SetTitleSize(0.05);
      FluxvslogE1[ncutMass]->GetYaxis()->SetTitleSize(0.05);
      FluxvslogE1[ncutMass]->Draw("AP");




      cFluxEGamma->cd();
      FluxvslogEGamma[ncutMass]->SetTitle(0);
      FluxvslogEGamma[ncutMass]->SetMaximum(5e4);
      FluxvslogEGamma[ncutMass]->SetMinimum(1e2+ 0*5e3);
      FluxvslogEGamma[ncutMass]->GetXaxis()->SetRangeUser(3.5, 6.0);
      FluxvslogEGamma[ncutMass]->SetMarkerStyle(20);
      FluxvslogEGamma[ncutMass]->SetMarkerColor(colorMark[ncutMass]);
      FluxvslogEGamma[ncutMass]->SetLineColor(colorMark[ncutMass]);
      FluxvslogEGamma[ncutMass]->GetXaxis()->SetTitle("log_{10}(E/GeV)");
      FluxvslogEGamma[ncutMass]->GetYaxis()->SetTitle("E^{2.6} d#Phi/dE [m^{-2} s^{-1} sr^{-1} GeV^{1.6}]");
      FluxvslogEGamma[ncutMass]->GetXaxis()->SetTitleSize(0.05);
      FluxvslogEGamma[ncutMass]->GetYaxis()->SetTitleSize(0.05);
      FluxvslogEGamma[ncutMass]->Draw("AP");

      cResponseMatrix->cd();

      h2DResponseMatrixRecvsTrue_mixed->GetXaxis()->SetTitleSize(0.05);
      h2DResponseMatrixRecvsTrue_mixed->GetYaxis()->SetTitleSize(0.05);
      h2DResponseMatrixRecvsTrue_mixed->GetYaxis()->SetRangeUser(3,6.4);
      h2DResponseMatrixRecvsTrue_mixed->GetZaxis()->SetTitleSize(0.05);
      //h2DResponseMatrixRecvsTrue_mixed->GetZaxis()->SetIndiceSize(1.5);
      //h2DResponseMatrixRecvsTrue_mixed->GetYaxis()->SetIndiceSize(1.5);
      h2DResponseMatrixRecvsTrue_mixed->GetZaxis()->SetTitle("P(E_{rec}|E)");
      h2DResponseMatrixRecvsTrue_mixed->GetYaxis()->SetTitle("log_{10}(E_{rec} /GeV)");
      h2DResponseMatrixRecvsTrue_mixed->GetXaxis()->SetTitle("log_{10}(E /GeV)");

      hFlux[ncutMass]->GetYaxis()->SetTitle("Counts");
      hFlux[ncutMass]->GetXaxis()->SetTitle("log_{10}(E_{rec} /GeV)");

      h2DResponseMatrixRecvsTrue_mixed->Draw("colz");



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                             Save plots in Root File

    Int_t    nsave=0;
    Char_t   nameRootFile[600];
    Char_t   nameObject[600][600];

    cout << endl << "Save CANVAS in root file? 0) No  1) Yes: ";
    cin  >> nsave;


    if(nsave == 1)
    {
       if(nUnfolding == 0)
       {

	 sprintf(nameRootFile, "%s/Plot_RawEFlux_Zeg%d_Mass%d_Cut_%s_MC_Bin%d_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT,  ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);

       }
       else
       {
	 sprintf(nameRootFile, "%s/Plot_UnfoldEFlux_Zeg%d_Mass%d_Cut_%s_MC_Bin%d_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);
       }
       TFile FSave(nameRootFile,"RECREATE");
       FSave.cd();

       FSave.WriteTObject(cFlux);
       sprintf(nameObject[ncutMass], "FluxvslogE_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvslogE[ncutMass]->Write(nameObject[ncutMass]);


       FSave.WriteTObject(cFluxE1);
       sprintf(nameObject[ncutMass], "FluxvslogE1_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvslogE1[ncutMass]->Write(nameObject[ncutMass]);

       FSave.WriteTObject(cFluxEGamma);
       sprintf(nameObject[ncutMass], "FluxvslogEGamma_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvslogEGamma[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "FluxvsEGamma_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvsEGamma[ncutMass]->Write(nameObject[ncutMass]);


       sprintf(nameObject[ncutMass], "Histogram_Zeg%d_Mass%d", ncutZenith, ncutMass);
       hFlux[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "h2DResponseMatrixRecvsTrue_Zeg%d_Mass%d", ncutZenith, ncutMass);
       h2DResponseMatrixRecvsTrue_mixed->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "HistogramTrue_Zeg%d_Mass%d", ncutZenith, ncutMass);
       hFlux_nTrue[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "HistogramTrue2_Zeg%d_Mass%d", ncutZenith, ncutMass);
       hFlux_nTrue2[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "h%d", ncutMass);
       hFlux[ncutMass]->Write(nameObject[ncutMass]);
       FSave.Close();
     }

 }
