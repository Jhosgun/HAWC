/**
 * @Author: J.A.M.S. <jorge-moralesas>
 * @Date:   2022-02-21T11:21:41-06:00
 * @Email:  jorge.morales@umich.mx
 * @Last modified by:   jorge-moralesas
 * @Last modified time: 2024-03-02T17:05:06-06:00
 */



{
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                           Clean Memory

    gDirectory->DeleteAll();
    gROOT->Reset();
    gROOT->cd();


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                               Load cuts

gROOT->ProcessLine(".x ./MyCuts_DQB_paper_CREETF.C");
gROOT->ProcessLine(".L ../Lib/BReference_HAWC.C");


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Define variables

    //Zenith Angle and Primary type
    Int_t    ncutZenith = 3;
    Int_t    ncutMass   = 0;
    Int_t    nCutAge_vs_logEnergy = 0;
    Int_t    ncutMassToReconstruct = 0;

    //Energy spectrum
    Int_t    ibinx = 0, nbinx = 22;
    Double_t Gamma_Index = 2.6;
    Double_t EGeV_Set[nbinx], logEGeV_Set[nbinx];
    Double_t DlogEGeV_Set[nbinx], DlogEhalf_Set[nbinx], DEGeV_Set[nbinx], DEhalf_Set[nbinx];
    Double_t Effective_Area_m2_GeV_sr_X_Flux_Set[nbinx], DEffective_Area_m2_GeV_sr_X_Flux_Set[nbinx];
    Double_t Effective_Area_m2_Set[nbinx], Effective_Area_m2_upp_Set[nbinx], Effective_Area_m2_low_Set[nbinx], DEffective_Area_m2_Set[nbinx];
    Double_t  logEGeV_minimum = 2.0;
    Double_t  logEGeV_maximum = 6.4;
    Double_t  lower_lgE_fit = 3.8, upper_lgE_fit = 3.8;

    //Variable for Cuts
    TCut MyCuts;

    //List
    Int_t   nev_List, iev_List, iev_Root;
    TEntryList *temp_List = NULL;
    TEntryList *ListALL   = NULL;
    Char_t      nameListAll[30];


    //Classify event according to mass composition
    Long64_t Classififed_Mass = 0;


    //Plotting Style
    Int_t  colorMark[12] = { 1, 2, 4, 8, 6, 41,50,25,28,36, 3, 5};
    Int_t  styleMark[12] = {20,22,25,26,24,27,20,22,25,26, 20, 20};


    //Weight
    Double_t Weight_TOTAL = 1.0;
    Double_t WeightFlux   = 1.0;


    //FindBin
    Int_t    binE = 0 0;
    Double_t lgE  = 0.0;
    Double_t Flux_lgE = 0.0;
    Double_t n_raw[9], Dn_raw[9], weight_mean[9], weight_sigma[9];
    Double_t Dn_weighted_vs_logE_total[nbinx];

    Char_t  DIROUT[60];
    sprintf(DIROUT, "CREETF_JCCUTS");
    //sprintf(DIROUT, "CREETF_QC");
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                      Choose parameters

    cout << endl << "Composition model based on CREAM-II data"<< endl;
    ncutMass  = 0;

    cout << endl << "Unfolding of mass group energy spectra using CREAM-II model"<< endl;
    cout << endl << "0) No cut   1) Light (cut at He)  2) Light (cut mid He&C)  3) Light (cut at C)   4) H (cut at H)  5) Z>=3 (cut at He) 6) Z>2 (cut mid He&C): ";
    cin  >> nCutAge_vs_logEnergy;

    Char_t  nameFile_nCutAge_vs_logEnergy[60];
    Char_t  namePlot_nCutAge_vs_logEnergy[60];
    switch(nCutAge_vs_logEnergy)
    {
        case 0:
            sprintf(nameFile_nCutAge_vs_logEnergy, "noMassCut");
            sprintf(namePlot_nCutAge_vs_logEnergy, "All Nuclei");
            ncutMassToReconstruct = 0;
            break;
        case 1:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 2:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 3:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 4:
            sprintf(nameFile_nCutAge_vs_logEnergy, "H_at_H");
            sprintf(namePlot_nCutAge_vs_logEnergy, "H");
            ncutMassToReconstruct = 1;
            break;
        case 5:
            sprintf(nameFile_nCutAge_vs_logEnergy, "Heavy_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 11;
            break;
        case 6:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
        case 7:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
        case 8:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
    }

    //cout << endl << "Select the zenith angle interval (deg)";
    cout << endl << "Zenith angle interval (deg)";
    cout << endl << "0)[0, 35] ";
    //cin  >> ncutZenith;
    ncutZenith=0;


    cout << endl << "Mass To Reconstruct";
    cout << endl << legendcutMass[ncutMassToReconstruct] << endl;



    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                         Define Canvas

    CanvasEffective_Area_m2 = new TCanvas("CanvasEffective_Area_m2","Canvas Effective Area m2",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    CanvasEffective_Area_m2->Clear();
    CanvasEffective_Area_m2->SetGridx(0);
    CanvasEffective_Area_m2->SetGridy(0);
    CanvasEffective_Area_m2->SetBorderMode(0);

    leg = new TLegend(0.187291,0.1684211,0.4397993,0.3136842,NULL,"brNDC");
   //leg->SetHeader("");
   leg->SetTextSize(0.03578947);
   leg->SetFillColor(0);
   leg->SetTextFont(72);
   leg->SetLineColor(0);



    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                         Define Histograms

    TH1D   *hEvents_Weighted[maxcutMass];
    Char_t  namehEvents_Weighted[maxcutMass][30];
    for(icutMass = 0; icutMass < maxcutMass; icutMass++)
    {
      sprintf(namehEvents_Weighted[icutMass], "hEvents_Weighted%d", icutMass);
      hEvents_Weighted[icutMass] = new TH1D(namehEvents_Weighted[icutMass], namehEvents_Weighted[icutMass], nbinx, logEGeV_minimum, logEGeV_maximum);
      hEvents_Weighted[icutMass]->Sumw2();
    }


    TProfile   *pWeigths[maxcutMass];
    Char_t  namepWeigths[maxcutMass][30];
    for(icutMass = 0; icutMass < maxcutMass; icutMass++)
    {
        sprintf(namepWeigths[icutMass], "pWeigths%d", icutMass);
        pWeigths[icutMass] = new TProfile(namepWeigths[icutMass], namepWeigths[icutMass], nbinx, logEGeV_minimum, logEGeV_maximum, "s");
        pWeigths[icutMass]->Sumw2();
    }


    TGraph *flux_GeV_m2_s_sr        = new TGraph(nbinx);
    TGraph *flux_GeV_m2_s_sr_EGamma = new TGraph(nbinx);

    TGraphErrors *gEffective_Area_m2          [maxcutMass];
    TGraphErrors *gEffective_Area_m2_Smoothed [maxcutMass];
    TGraphErrors *gEffective_Area_m2_upp      [maxcutMass];
    TGraphErrors *gEffective_Area_m2_low      [maxcutMass];
    TGraphErrors *gEffective_Area_m2_Smoothed_upp      [maxcutMass];
    TGraphErrors *gEffective_Area_m2_Smoothed_low      [maxcutMass];


    TF1 *powerlaw = new TF1("powerlaw", "[0]*pow(10.0, x)**[1]", logEGeV_minimum,logEGeV_maximum);
    powerlaw->SetParameters(2e-16, -1.5);


    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                         Load Data

    //Internal Variables
    ULong64_t mc_corsikaParticleId_Load;
    Double_t  mc_logEnergy_Load;

    Double_t  sweets_IWgt_Load;
    
    Double_t   rec_mlout_Load;
//    Double_t   rec_protonlheEnergy_Load;
    ULong64_t  rec_nHit_Load;
    Double_t   rec_zenithAngle_Load;
    ULong64_t  rec_coreFiduScale_Load;
    Double_t   rec_LDFAge_Load;
    ULong64_t  rec_nChAvail_Load;
    ULong64_t  rec_coreFitStatus_Load;
    ULong64_t  rec_angleFitStatus_Load;

    //Open ROOT file
    TChain *chain_new = new TChain("XCDF", "");
    /*
     //Pass 4
    chain_new->Add("/lustre/hawcz01/hawcroot/sim/reco/aerie_svn_42375a/config_hawc_v101/daqsim-config/reco_files/sweets/2.63_3.45e-11_1000000_20_1.0/succeeded/2.63_3.45e-11_1000000_20_1.0_combined_rec.root");
    */
    
    // pass5.1 con Modelo 2
    //chain_new->Add("./data/2.63_3.45e-11_1000000_20_1.0_combined_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_proton_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_helium_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_carbon_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_oxygen_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_neon_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_magnesium_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_silicon_rec.root");
    chain_new->Add("./MCdata/2.63_3.45e-11_1000000_20_1.0_iron_rec.root");
    /*
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_proton_rec.root");
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_helium_rec.root");
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_carbon_rec.root");
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_oxygen_rec.root");
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_neon_rec.root");
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_magnesium_rec.root");
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_silicon_rec.root");
    chain_new->Add("/lustre/hawcz01/scratch/userspace/tcapistran/CREnergyMLT/Model2AddNN/MC/2.63_3.45e-11_1000000_20_1.0_iron_rec.root");
     */

    
    /*
     //Jorge original
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_proton_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_helium_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_carbon_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_oxygen_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_neon_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_magnesium_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_silicon_daq.root");
    chain_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim/mc_iron_daq.root");
     */


/*
 //Jorge original
    TChain *chain2_new = new TChain("XCDF", "");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_proton_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_helium_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_carbon_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_oxygen_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_neon_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_magnesium_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_silicon_new_sweet.root");
    chain2_new->Add("/Users/jorge-moralesas/HAWC/MC_data/DAQSim_friend/mc_iron_new_sweet.root");
    chain_new->AddFriend(chain2_new);
*/

   //Disable all branches
   chain_new->SetBranchStatus("*",0);

   //Set Status of Branch
   chain_new->SetBranchStatus("mc.corsikaParticleId",1);
   chain_new->SetBranchStatus("mc.logEnergy",1);

//   chain_new->SetBranchStatus("sweets.IWgt.new",1);
chain_new->SetBranchStatus("sweets.IWgt",1);

   chain_new->SetBranchStatus("rec.tfout",1);
   chain_new->SetBranchStatus("rec.nHit",1);
   chain_new->SetBranchStatus("rec.zenithAngle",1);
   chain_new->SetBranchStatus("rec.coreFiduScale",1);
   chain_new->SetBranchStatus("rec.LDFAge",1);
   chain_new->SetBranchStatus("rec.LDFAmp",1);
   chain_new->SetBranchStatus("rec.nChAvail",1);

   chain_new->SetBranchStatus("rec.CxPE40XnCh",1);
   chain_new->SetBranchStatus("rec.CxPE40",1);
    
    chain_new->SetBranchStatus("rec.coreFitStatus",1);
    chain_new->SetBranchStatus("rec.angleFitStatus",1);


   //Direction of branch to internal variable
   chain_new->SetBranchAddress("mc.corsikaParticleId",&mc_corsikaParticleId_Load);
   chain_new->SetBranchAddress("mc.logEnergy",&mc_logEnergy_Load);

//   chain_new->SetBranchAddress("sweets.IWgt.new",&sweets_IWgt_Load);
chain_new->SetBranchAddress("sweets.IWgt",&sweets_IWgt_Load);

   chain_new->SetBranchAddress("rec.tfout",&rec_mlout_Load);
   chain_new->SetBranchAddress("rec.nHit",&rec_nHit_Load);
   chain_new->SetBranchAddress("rec.zenithAngle",&rec_zenithAngle_Load);
   chain_new->SetBranchAddress("rec.coreFiduScale",&rec_coreFiduScale_Load);
   chain_new->SetBranchAddress("rec.LDFAge",&rec_LDFAge_Load);
   chain_new->SetBranchAddress("rec.nChAvail",&rec_nChAvail_Load);
    chain_new->SetBranchAddress("rec.coreFitStatus",&rec_coreFitStatus_Load);
    chain_new->SetBranchAddress("rec.angleFitStatus",&rec_angleFitStatus_Load);
    


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                  Define mass separation cuts


   Char_t nameplot[500];
// CHECK IF THAT WORKS WITHOUT THIS PART
   //ONLY USE FOR ZENITH BIN NUMBER 0
   if(ncutZenith == 0)
    {
      cout << endl << "@ Separation using Age vs logEnergy plot for zenith bin number 0" << endl;
      TFile file_cut_H_He("./v6/Plots_Age_Zeg0_MC_Fit_H_He_DQB.root");
      TFile file_cut_He_C("./v6/Plots_Age_Zeg0_MC_Fit_He_C_DQB.root");
    }
   file_cut_H_He.cd();
   cut_H = (TF1*)gDirectory->Get("lineAge_vs_protonlheEnergy_Zeg0_Mass1");
   file_cut_He_C.cd();
   cut_He = (TF1*)gDirectory->Get("lineAge_vs_protonlheEnergy_Zeg0_Mass2");
   cut_C  = (TF1*)gDirectory->Get("lineAge_vs_protonlheEnergy_Zeg0_Mass3");



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                 Select and Work out data

    //Generate List with selected data
    //Original Jorge
    //MyCuts = (mycutMass[0] && mycutZenith[ncutZenith] && mycutcoreFiduScale && mycutCxPE40  && mycutlogEvsZenith[ncutZenith]);
    // Quality CUTS
    //MyCuts = (mycutMass[0] && mycutZenith[ncutZenith] && mycutlogEvsZenith[ncutZenith] && mycutcoreFiduScale && mycutnHit && mycutcoreFitStatus && mycutangleFitStatus);
    //JC CUTS
    MyCuts = (mycutMass[0] && mycutZenith[ncutZenith] && mycutlogEvsZenith[ncutZenith] && mycutcoreFiduScale && mycutCxPE40 && mycutnHit && mycutcoreFitStatus && mycutangleFitStatus);
    cout << "LOS CORTES: " << MyCuts.Print() << endl;
    
    chain_new->Draw(">>Save_List", MyCuts, "entrylist");
    temp_List  = (TEntryList*)gDirectory->Get("Save_List");
    ListAll    = (TEntryList*)temp_List.Clone();
    sprintf(nameListAll, "ListAll");
    ListAll->SetName(nameListAll);

    //Upload list
    chain_new->SetEntryList(ListAll);
    chain_new->Draw("mc.logEnergy");

    //Read number of events
    nev_List = (Int_t)chain_new->GetSelectedRows();


    //Read each event
    gROOT->cd();
    for(iev_List = 0; iev_List < nev_List; iev_List++)
    {
        //Get Event and load values of branches
        iev_Root = chain_new->GetEntryNumber(iev_List);
        chain_new->GetEntry(iev_Root);
        Weight_TOTAL = sweets_IWgt_Load;


        //Classify event
        Classififed_Mass    = TMath::BinarySearch(9,cutMass, mc_corsikaParticleId_Load);
        //Double_t observable = rec_protonlheEnergy_Load;
        Double_t observable = rec_mlout_Load;

        //Separation criteria
        Int_t nPass = 0;
        switch(nCutAge_vs_logEnergy)
        {
            case 0:
                nPass = 1;
                break;
            case 1:
                if(rec_LDFAge_Load < cut_He.Eval(observable)) nPass = 1;
                break;
            case 2:
                if(rec_LDFAge_Load <  (cut_He.Eval(observable) + cut_C.Eval(observable))/2.0) nPass = 1;
                break;
            case 3:
                if(rec_LDFAge_Load < cut_C.Eval(observable)) nPass = 1;
                break;
            case 4:
                if(rec_LDFAge_Load < cut_H.Eval(observable)) nPass = 1;
                break;
            case 5:
                if(rec_LDFAge_Load > cut_He.Eval(observable)) nPass = 1;
                break;
            case 6:
                if(rec_LDFAge_Load >=  (cut_He.Eval(observable) + cut_C.Eval(observable))/2.0) nPass = 1;
                break;
            case 7:
                 if(rec_LDFAge_Load >= cut_C.Eval(observable)) nPass = 1;
                break;
            case 8:
                 if(rec_LDFAge_Load >= cut_He.Eval(observable)) nPass = 1;
                break;
        }

       if(nPass == 1)
       {

            	//Weighted events
            	hEvents_Weighted[ncutMassToReconstruct]->Fill(mc_logEnergy_Load, Weight_TOTAL);

            	//Weight statistics
            	pWeigths[ncutMassToReconstruct]->Fill(mc_logEnergy_Load, Weight_TOTAL, 1);

       }
    }


    //Normalization flux
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
       lgE      = hEvents_Weighted[ncutMassToReconstruct]->GetBinCenter(ibinx+1);
       Flux_lgE = 0.0;
       switch(ncutMassToReconstruct)
       {
         case 0:
             for(icutMass = 1; icutMass <= 8; icutMass++)
             {
				Flux_lgE += BReference_Flux_m2ssrGeV_X_Escale(icutMass, lgE, 0.0);
             }
             break;
        case 1:
               for(icutMass = 1; icutMass <= 1; icutMass++)
               {
                   Flux_lgE += BReference_Flux_m2ssrGeV_X_Escale(icutMass, lgE, 0.0);
               }
               break;
        case 8:
               for(icutMass = 8; icutMass <= 8; icutMass++)
               {
                   Flux_lgE += BReference_Flux_m2ssrGeV_X_Escale(icutMass, lgE, 0.0);
               }
               break;
        case 9:
             for(icutMass = 1; icutMass <= 2; icutMass++)
             {
                 Flux_lgE += BReference_Flux_m2ssrGeV_X_Escale(icutMass, lgE, 0.0);
             }
             break;
        case 10:
             for(icutMass = 3; icutMass <= 8; icutMass++)
             {
                 Flux_lgE += BReference_Flux_m2ssrGeV_X_Escale(icutMass, lgE, 0.0);
             }
             break;
        case 11:
             for(icutMass = 2; icutMass <= 8; icutMass++)
             {
				 Flux_lgE += BReference_Flux_m2ssrGeV_X_Escale(icutMass, lgE, 0.0);
             }
             break;
       }
       flux_GeV_m2_s_sr->SetPoint(ibinx, lgE, Flux_lgE);
    }




    //Prepare arrays for error calculation
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        Dn_weighted_vs_logE_total[ibinx] = 0.0;
        //Dn_weighted_vs_logE_total[ibinx] = hEvents_Weighted[ncutMassToReconstruct]->GetBinContent(ibinx+1)/
        //                                   hEvents_Weighted[ncutMassToReconstruct]->GetBinError(ibinx+1);
        //Dn_weighted_vs_logE_total[ibinx]*= hEvents_Weighted[ncutMassToReconstruct]->GetBinContent(ibinx+1)/
        //                                   Dn_weighted_vs_logE_total[ibinx]**2.0;
	    Dn_weighted_vs_logE_total[ibinx] = hEvents_Weighted[ncutMassToReconstruct]->GetBinError(ibinx+1);
    }



     //Energy spectrum
      for(ibinx = 0; ibinx < nbinx; ibinx++)
      {
    	//Fill Arrays
        logEGeV_Set                          [ibinx] = hEvents_Weighted[ncutMassToReconstruct]->GetBinCenter(ibinx+1);
        EGeV_Set                             [ibinx] = pow(10, logEGeV_Set[ibinx]);
        DlogEGeV_Set                         [ibinx] = hEvents_Weighted[ncutMassToReconstruct]->GetBinWidth (ibinx+1);
        DEGeV_Set                            [ibinx] = pow(10, logEGeV_Set[ibinx] + DlogEGeV_Set[ibinx]/2)
                                                      -pow(10, logEGeV_Set[ibinx] - DlogEGeV_Set[ibinx]/2);
        DlogEhalf_Set                        [ibinx] = DlogEGeV_Set[ibinx]*0.0/2.0;
        DEhalf_Set                           [ibinx] = 0.0;


        //Calculate effective area x flux
        Effective_Area_m2_GeV_sr_X_Flux_Set  [ibinx] = hEvents_Weighted[ncutMassToReconstruct] ->GetBinContent(ibinx+1);
        DEffective_Area_m2_GeV_sr_X_Flux_Set [ibinx] = Dn_weighted_vs_logE_total[ibinx];


        Effective_Area_m2_GeV_sr_X_Flux_Set [ibinx] =  Effective_Area_m2_GeV_sr_X_Flux_Set[ibinx]/flux_GeV_m2_s_sr->Eval(logEGeV_Set [ibinx]);
        DEffective_Area_m2_GeV_sr_X_Flux_Set[ibinx] = DEffective_Area_m2_GeV_sr_X_Flux_Set[ibinx]/flux_GeV_m2_s_sr->Eval(logEGeV_Set [ibinx]);


        //Calculate effective area
        Effective_Area_m2_Set [ibinx]  =    Effective_Area_m2_GeV_sr_X_Flux_Set[ibinx]/(DEGeV_Set[ibinx]*DOmegaSr[ncutZenith]);
        DEffective_Area_m2_Set[ibinx]  =   DEffective_Area_m2_GeV_sr_X_Flux_Set[ibinx]/(DEGeV_Set[ibinx]*DOmegaSr[ncutZenith]);

        if(Effective_Area_m2_Set [ibinx] == 0) DEffective_Area_m2_Set[ibinx]  = 0.0;

        Effective_Area_m2_upp_Set[ibinx]  =   Effective_Area_m2_Set [ibinx] + DEffective_Area_m2_Set[ibinx];
        Effective_Area_m2_low_Set[ibinx]  =   Effective_Area_m2_Set [ibinx] - DEffective_Area_m2_Set[ibinx];
      }
      gEffective_Area_m2    [ncutMassToReconstruct] = new TGraphErrors(nbinx, logEGeV_Set, Effective_Area_m2_Set, NULL, DEffective_Area_m2_Set);
      gEffective_Area_m2_upp[ncutMassToReconstruct] = new TGraphErrors(nbinx, logEGeV_Set, Effective_Area_m2_upp_Set, NULL, DEffective_Area_m2_Set);
      gEffective_Area_m2_low[ncutMassToReconstruct] = new TGraphErrors(nbinx, logEGeV_Set, Effective_Area_m2_low_Set, NULL, DEffective_Area_m2_Set);
      gEffective_Area_m2_Smoothed[ncutMassToReconstruct] = new TGraphErrors(nbinx, logEGeV_Set, Effective_Area_m2_Set, NULL, DEffective_Area_m2_Set);
      gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct] = new TGraphErrors(nbinx, logEGeV_Set, Effective_Area_m2_upp_Set, NULL, DEffective_Area_m2_Set);
      gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct] = new TGraphErrors(nbinx, logEGeV_Set, Effective_Area_m2_low_Set, NULL, DEffective_Area_m2_Set);


/*
      for(ibinx = 0; ibinx < nbinx; ibinx++)
      {

         if(logEGeV_Set[ibinx] > 4.0 && logEGeV_Set[ibinx] < 5.8)
         {
           Effective_Area_m2_Set [ibinx] = Effective_Area_m2_Set [ibinx-1] + Effective_Area_m2_Set [ibinx] + Effective_Area_m2_Set [ibinx+1];
           Effective_Area_m2_Set [ibinx] = Effective_Area_m2_Set [ibinx]/3.0;

           gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetPoint(ibinx, logEGeV_Set[ibinx], Effective_Area_m2_Set [ibinx]);
        }
      }
*/



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                           Fits

    lower_lgE_fit = 4.3;
    upper_lgE_fit = 6.0;

    //Smoothing mean values
    TF1 *user = new TF1("user", "pol5", 3, 6.0);
    TFitResultPtr r = gEffective_Area_m2[ncutMassToReconstruct]->Fit("user","S","S",lower_lgE_fit, upper_lgE_fit);

    TF1 *user2 = new TF1("user2", "pol5", 3, 6.0);
    TFitResultPtr r = gEffective_Area_m2[ncutMassToReconstruct]->Fit("user2","S","S",3.0, 4.5);

    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
       if (lower_lgE_fit < logEGeV_Set[ibinx] && logEGeV_Set[ibinx] < upper_lgE_fit)
       {
           Double_t x  [1]= {logEGeV_Set[ibinx]};
           Double_t err[1]= { 0.0};
           r->GetConfidenceIntervals(1, 1, 1,  x, err, 0.3413, false);
           DEffective_Area_m2_Set[ibinx] = err[0];

           gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetPoint     (ibinx, x[0], user->Eval(x[0]));
           //gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetPointError(ibinx, 0.0, DEffective_Area_m2_Set[ibinx]);
       }
    }



    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        if (logEGeV_Set[ibinx] <= lower_lgE_fit)
        {
            Double_t x  [1]= {logEGeV_Set[ibinx]};
            Double_t err[1]= { 0.0};
            r->GetConfidenceIntervals(1, 1, 1,  x, err, 0.3413, false);
            DEffective_Area_m2_Set[ibinx] = err[0];

            gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetPoint     (ibinx, x[0], user2->Eval(x[0]));
            //gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetPointError(ibinx, 0.0, DEffective_Area_m2_Set[ibinx]);
        }
    }



    //Smoothing upper value
    TFitResultPtr r = gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->Fit("user","S","S",lower_lgE_fit, upper_lgE_fit);
    TFitResultPtr r2 = gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->Fit("user2","S","S",2.9, 4.5);

    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        if (lower_lgE_fit < logEGeV_Set[ibinx] && logEGeV_Set[ibinx] < upper_lgE_fit)
        {
            Double_t x  [1]= {logEGeV_Set[ibinx]};
            Double_t err[1]= { 0.0};;
            r->GetConfidenceIntervals(1, 1, 1,  x, err, 0.3413, false);
            DEffective_Area_m2_Set[ibinx] = err[0];

            gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->SetPoint     (ibinx, x[0], user->Eval(x[0]));
            gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->SetPointError(ibinx, 0.0, DEffective_Area_m2_Set[ibinx]);
        }
    }

    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        if (logEGeV_Set[ibinx] < lower_lgE_fit)
        {
            Double_t x  [1]= {logEGeV_Set[ibinx]};
            Double_t err[1]= { 0.0};;
            r->GetConfidenceIntervals(1, 1, 1,  x, err, 0.3413, false);
            DEffective_Area_m2_Set[ibinx] = err[0];

            gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->SetPoint     (ibinx, x[0], user2->Eval(x[0]));
            gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->SetPointError(ibinx, 0.0, DEffective_Area_m2_Set[ibinx]);
        }
    }


    //Smoothing lower value
    TFitResultPtr r = gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->Fit("user","S","S",lower_lgE_fit, upper_lgE_fit);
    TFitResultPtr r2 = gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->Fit("user2","S","S",2.9, 4.5);

    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        if (lower_lgE_fit < logEGeV_Set[ibinx] && logEGeV_Set[ibinx] < upper_lgE_fit)
        {
            Double_t x  [1]= {logEGeV_Set[ibinx]};
            Double_t err[1]= { 0.0};;
            r->GetConfidenceIntervals(1, 1, 1,  x, err, 0.3413, false);
            DEffective_Area_m2_Set[ibinx] = err[0];

            gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->SetPoint     (ibinx, x[0], user->Eval(x[0]));
            gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->SetPointError(ibinx, 0.0, DEffective_Area_m2_Set[ibinx]);
        }
    }

    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
        if (logEGeV_Set[ibinx] < lower_lgE_fit)
        {
            Double_t x  [1]= {logEGeV_Set[ibinx]};
            Double_t err[1]= { 0.0};;
            r->GetConfidenceIntervals(1, 1, 1,  x, err, 0.3413, false);
            DEffective_Area_m2_Set[ibinx] = err[0];

            gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->SetPoint     (ibinx, x[0], user2->Eval(x[0]));
            gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->SetPointError(ibinx, 0.0, DEffective_Area_m2_Set[ibinx]);
        }
    }



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                       Plot data

    CanvasEffective_Area_m2->cd();
    gEffective_Area_m2[ncutMassToReconstruct]->SetTitle(0);
    gEffective_Area_m2[ncutMassToReconstruct]->SetMaximum(3e5);
    gEffective_Area_m2[ncutMassToReconstruct]->SetMinimum(1e1);
    gEffective_Area_m2[ncutMassToReconstruct]->SetMarkerStyle(20);
    gEffective_Area_m2[ncutMassToReconstruct]->GetXaxis()->SetRangeUser(3.0, 6.0);
    gEffective_Area_m2[ncutMassToReconstruct]->SetMarkerColor(colorMark[ncutMass]);
    gEffective_Area_m2[ncutMassToReconstruct]->SetLineColor(colorMark[ncutMass]);
    gEffective_Area_m2[ncutMassToReconstruct]->GetXaxis()->SetTitle("log_{10}(E/GeV)");
    gEffective_Area_m2[ncutMassToReconstruct]->GetYaxis()->SetTitle("A_{eff} (m^{2})");
    gEffective_Area_m2[ncutMassToReconstruct]->GetXaxis()->SetTitleSize(0.05);
    gEffective_Area_m2[ncutMassToReconstruct]->GetYaxis()->SetTitleSize(0.05);
    gEffective_Area_m2[ncutMassToReconstruct]->Draw("AP");

    TLine *line = new TLine(3.0,22000,6.0,22000);
    line->SetLineStyle(2);
    line->SetLineWidth(3);
    line->SetLineColor(kAzure+2);
    line->Draw();

    leg->AddEntry(gEffective_Area_m2[0],"Effective Area","p");
    leg->AddEntry(line,"HAWC geometrical area","l");
    leg->Draw("lsame");
    gPad->Modified();


    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetTitle(0);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetMaximum(1e5);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetMinimum(1e1);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetMarkerStyle(20);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->GetXaxis()->SetRangeUser(3.0, 6.4);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetMarkerColor(colorMark[ncutMassToReconstruct]);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->SetLineColor(colorMark[ncutMassToReconstruct]);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->GetXaxis()->SetTitle("log_{10}(E^{True}/GeV)");
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->GetYaxis()->SetTitle("A_{eff} (m^{2})");
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->GetXaxis()->SetTitleSize(0.05);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->GetYaxis()->SetTitleSize(0.05);
    gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->Draw("psame");

    gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->SetLineColor(kViolet);
    gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->SetLineColor(kViolet);
    gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->Draw("lsameX");
    gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->Draw("lsameX");





//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                             Save plots in Root File

    Int_t    nsave=0;
    Char_t   nameRootFile[600];
    Char_t   nameObject[600][600];

    cout << endl << "Save CANVAS in root file? 0) No  1) Yes: ";
    cin  >> nsave;


    if(nsave == 1)
    {

       sprintf(nameRootFile, "%s/newEA_Plot_EffArea_Zeg%d_Mass%d_Cut_%s_Bin%d_MC_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);

       TFile FSave(nameRootFile,"RECREATE");
       FSave.cd();

       FSave.WriteTObject(CanvasEffective_Area_m2);
       sprintf(nameObject[ncutMassToReconstruct], "gEffective_Area_m2_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
       gEffective_Area_m2[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);

       sprintf(nameObject[ncutMassToReconstruct], "gEffective_Area_m2_Smoothed_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
       gEffective_Area_m2_Smoothed[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);

       sprintf(nameObject[ncutMassToReconstruct], "gEffective_Area_m2_upp_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
       gEffective_Area_m2_upp[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);



       sprintf(nameObject[ncutMassToReconstruct], "gEffective_Area_m2_Smoothed_upp_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
       gEffective_Area_m2_Smoothed_upp[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);


        sprintf(nameObject[ncutMassToReconstruct], "gEffective_Area_m2_low_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
        gEffective_Area_m2_low[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);


        sprintf(nameObject[ncutMassToReconstruct], "gEffective_Area_m2_Smoothed_low_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
        gEffective_Area_m2_Smoothed_low[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);

       sprintf(nameObject[ncutMassToReconstruct], "Histogram_Events_Weighted_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
       hEvents_Weighted[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);

       sprintf(nameObject[ncutMassToReconstruct], "Profile_Weigths_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
       pWeigths[ncutMassToReconstruct]->Write(nameObject[ncutMassToReconstruct]);

       FSave.Close();
     }
 }
