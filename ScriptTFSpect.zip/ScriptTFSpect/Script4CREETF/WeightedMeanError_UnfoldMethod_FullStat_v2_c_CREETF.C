/**
 * @Author: J.A.M.S. <jorge-moralesas>
 * @Date:   2021-09-15T13:26:29-05:00
 * @Email:  jorge.morales@umich.mx
 * @Last modified by:   jorge-moralesas
 * @Last modified time: 2023-11-03T13:16:31-06:00
 */




//   ******************************************************************************
//   *                  WeightedMeanError_UnfoldMethod.C(February  2018)          *
//   *                    Get Systematics for Gold/Bayesian Method                *
//   ******************************************************************************
{
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                     Presentation


    cout<< endl << endl;
    cout<< "*************************************************************************" << endl;
    cout<< "*                    WeightedMeanError_UnfoldMethod.C                   *" << endl;
    cout<< "*                   Get Systematics for Gold/bayesian Method            *" << endl;
    cout<< "*                            (February 2018)                            *" << endl;
    cout<< "*************************************************************************" << endl;


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                     Clean memory


    //Clean Memory. Delete objects in HEAP.
    gDirectory->DeleteAll();

    //Clean Memory. Delete objects in STACK (global and local variables)
    gROOT->Reset();


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                      Load cuts and legends and programs for unfolding

    Int_t    nmethod = 0;

    cout << endl << "Choose 0) Gold or 1) Bayesian algorithm =";
    cin  >> nmethod;

    if(nmethod == 0)
    {
        gROOT->ProcessLine(".L ../Lib/smoothingGold_v4.c");
                                                                                    //CHOOSE: GOLDEN
    }
    else
    {
        //gROOT->ProcessLine(".L ~/HAWC/Analisis/tests/lib/test_smoothing.c");
        //gROOT->ProcessLine(".L ~/HAWC/Analisis/tests/lib/Subroutine_Bayesian_plus_efficiency.c");
        gROOT->ProcessLine(".L ../Lib/smoothing_v4.c");
                                                                                  //CHOOSE: BAYESIAN
    }


    Char_t  DIROUT[60];
    sprintf(DIROUT, "CREETF_JCCUTS");
    //sprintf(DIROUT, "CREETF_QC");
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                               General purpose Variables

    Int_t    ibinx =0, nbinx = 22;                                   // Number of bins in X axis
    Int_t    iexp  =0, nexp  = 50;                                   // Number of experiments
    Int_t    iitera=0, nitera= 500;                                   // Number of Iterations
    Int_t    ncutZenith = 5;
    Int_t    ncutMass   = 0;
    Int_t    icounter   = 0;

    Int_t    nMC = 0;

    Char_t   titleData[90];

    Char_t   nameRootFile[300];                                     // Name of Root File to save data
    Char_t   nameDataFile[300];                                     // Name of Data File to save data table
    Char_t   namePathAndRootFile[400];
    Char_t   nameDescription[400];
    Char_t   nameNmuCFRootFile[400];

    Int_t    colorMark[16] = { 1, 2, 4, 6, 8, 41, 42, 2, 46, 45, 3, 5, 1, 2, 4, 6};
                                                                   // Plotting style
    Int_t    colorLine[16] = {36, 9, 4, 7, 8, 41, 42, 2, 46, 45, 3, 5, 1, 2, 4, 6};
    Int_t    styleMark[16] = {20,22,25,26,24,27,21,23,28,5,20,22,25,26,24,27};

    Int_t    jumpstepsitera = 1;


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                   Choose parameters

    cout << endl << "@ Exp(0) MC(1) :";
    cin  >> nMC;

    //cout << endl << "Select the zenith angle interval (deg)";
    cout << endl << "The zenith angle interval (deg)";
    cout << endl << "0)[   0,16.7] : ";
    //cin  >> ncutZenithM;
    ncutZenith=0;

    cout << endl << "@ Number of Experiments to calculate uncertainties in each iteration (max 200) =";
    cin  >> nexp;


    cout << endl << "@ Number of iterations  (max 250) =";
    cin  >> nitera;


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                             Choose Selection criteria for mass group

    Int_t    nCutAge_vs_logEnergy  = 0;
    Int_t    ncutMassToReconstruct = 0;

    cout << endl << "Unfolding of mass group energy spectra using CREAM-II model"<< endl;
    cout << endl << "0) No cut   1) Light (cut at He)  2) Light (cut mid He&C)  3) Light (cut at C)   4) H (cut at H)  5) Z>1 (cut at He)  6) Z>2 (cut mid He&C): ";
    cin  >> nCutAge_vs_logEnergy;

	Char_t  nameFile_nCutAge_vs_logEnergy[60];
    Char_t  namePlot_nCutAge_vs_logEnergy[60];
    switch(nCutAge_vs_logEnergy)
    {
        case 0:
            sprintf(nameFile_nCutAge_vs_logEnergy, "noMassCut");
            sprintf(namePlot_nCutAge_vs_logEnergy, "All Nuclei");
            ncutMassToReconstruct = 0;
            break;
        case 1:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 2:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 3:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 4:
            sprintf(nameFile_nCutAge_vs_logEnergy, "H_at_H");
            sprintf(namePlot_nCutAge_vs_logEnergy, "H");
            ncutMassToReconstruct = 1;
            break;
        case 5:
            sprintf(nameFile_nCutAge_vs_logEnergy, "Heavy_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 11;
            break;
        case 6:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
        case 7:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
        case 8:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
    }


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                Get Spectrum

   //Read Spectrum
   TH1D  *histogram_load = NULL;
   TH1D  *NvslogENewAll  = NULL;
   Char_t name_ROOTFILE_File_Histogram[300];

    //CHOOSE Spectrum for unfolding
    if(nMC == 0)
    {   cout << "USE REAL DATA" << endl;
         sprintf(name_ROOTFILE_File_Histogram, "%s/Plot_RawEFlux_Zeg%d_Mass%d_Cut_%s_Exp_Bin%d_ObtainMass%d_AgevsEnergy_FullStat_DQB_5481.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);
    }
    else
    {   cout << "USE MC" << endl;
      	 sprintf(name_ROOTFILE_File_Histogram, "%s/Plot_RawEFlux_Zeg%d_Mass%d_Cut_%s_MC_Bin%d_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);
    }
    TFile RootFile_ref_Set(name_ROOTFILE_File_Histogram);
    histogram_load = (TH1D*)gDirectory->Get("h0");

    gROOT->cd();
    NvslogENewAll = (TH1D*)(histogram_load)->Clone();
    nbinx = NvslogENewAll->GetXaxis()->GetNbins();



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                Get response matrix

    //CHOOSE Response matrix
    TH2D     *histogram2D_load = NULL;
    TH2D     *h2DResponseMatrix= NULL;
    TH1D     *h1DSeed= NULL;
    Char_t   name_ROOTFile_ResponseMatrixRecvsTrue[300];
    Char_t   nameObject[300];
    
    cout << "BINX: "<< nbinx << endl;

    sprintf(name_ROOTFile_ResponseMatrixRecvsTrue, "%s/Plot_RawEFlux_Zeg%d_Mass%d_Cut_%s_MC_Bin%d_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);
    TFile RootFile_ref_Set2(name_ROOTFile_ResponseMatrixRecvsTrue);
    sprintf(nameObject, "h2DResponseMatrixRecvsTrue_Zeg%d_Mass0", ncutZenith);
    histogram2D_load = (TH2D*)gDirectory->Get(nameObject);
    h1DSeed =  (TH1D*)gDirectory->Get("HistogramTrue_Zeg0_Mass0");

    gROOT->cd();
    h2DResponseMatrix = (TH2D*)(histogram2D_load)->Clone();



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                Get efficiency


    //Read Efficiency plot for Unfolding
    Char_t name_ROOTFILE_EfficiencyvsTrueEnergy [300];
    Char_t name_gEfficiencyvsTrueEnergy         [300];

    sprintf(name_ROOTFILE_EfficiencyvsTrueEnergy, "%s/newEA_Plot_EffArea_Zeg%d_Mass%d_Cut_%s_Bin%d_MC_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);

    TFile ROOTFile_EfficiencyvsTrueEnergy(name_ROOTFILE_EfficiencyvsTrueEnergy);

    sprintf(name_gEfficiencyvsTrueEnergy, "gEffective_Area_m2_Smoothed_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
    gEfficiencyvsTrueEnergy = (TGraphErrors*)gDirectory->Get(name_gEfficiencyvsTrueEnergy);


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                   Declare variables and initialize

    //Declare experiments
    Int_t     ibinx_threshold   = 0;
    Double_t  logEGeV_threshold = 4.0;

    Int_t     ibinx_maximum   = 0;
    Double_t  logEGeV_maximum = 6.0;

    Double_t  WMSE  = 0.0;
    TGraph   *gWMSE = new TGraph();
    TGraph   *gStatError_avrg    [nitera+1];
    TGraph   *gSystError_avrg    [nitera+1];
    TGraph   *gRelativeError_avrg[nitera+1];

    Double_t bin_events_raw = 0;
    Double_t bin_events_ff  = 0;
    Int_t    ndf = 0;
    Double_t Chi2     = 0.0;
    Double_t Chi2_ndf = 0.0;
    Double_t relative_error = 0.0;
    TGraph *Chi2_vs_iterations = new TGraph();
    TGraph *RelativeError_vs_iterations = new TGraph();

    TRandom3 *r1 = new TRandom3();
    TH1D    *NvslogENewAll_unfolded;
    TH1D    *NvslogENewAll_forwardfolded;
    TH1D    *NvslogENewAll_experiments[nexp];
    TH1D    *NvslogENewAll_experiments_unfolded[nexp];
    TH1D    *NvslogENewAll_experiments_forwardfolded[nexp];
    TH1D    *NvslogENewAll_experiments_reunfolded[nexp];

    NvslogENewAll_unfolded = (TH1D*)NvslogENewAll->Clone();
    NvslogENewAll_unfolded->Reset();

    NvslogENewAll_forwardfolded = (TH1D*)NvslogENewAll->Clone();
    NvslogENewAll_forwardfolded->Reset();

    for(iexp = 0; iexp < nexp; iexp++)
    {
       //Create Histogram for experiments
       NvslogENewAll_experiments              [iexp] = (TH1D*)NvslogENewAll->Clone();
       NvslogENewAll_experiments_unfolded     [iexp] = (TH1D*)NvslogENewAll->Clone();
       NvslogENewAll_experiments_forwardfolded[iexp] = (TH1D*)NvslogENewAll->Clone();
       NvslogENewAll_experiments_reunfolded   [iexp] = (TH1D*)NvslogENewAll->Clone();


       NvslogENewAll_experiments              [iexp]->Reset();
       NvslogENewAll_experiments_unfolded     [iexp]->Reset();
       NvslogENewAll_experiments_forwardfolded[iexp]->Reset();
       NvslogENewAll_experiments_reunfolded   [iexp]->Reset();
    }


    cout << endl << "@ Give me energy interval for uncertainty calculations";
    cout << endl << "@ logEGeV_minimum" << endl;
    cin  >> logEGeV_threshold;
    ibinx_threshold = NvslogENewAll->FindBin(logEGeV_threshold);

    cout << endl << "@ logEGeV_maximum" << endl;
    cin  >> logEGeV_maximum;
    ibinx_maximum   = NvslogENewAll->FindBin(logEGeV_maximum);



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                  Generate experiments with random generator: Assume Poisson inside each bin

    //Set values for bins of experiments
    for(iexp = 0; iexp < nexp; iexp++)
    {
       NvslogENewAll_experiments[iexp]->Reset();

       //Fill with random generator
       for(ibinx = 0; ibinx < nbinx; ibinx++)
       {
           if(NvslogENewAll->GetBinContent(ibinx+1) > 1e2)  NvslogENewAll_experiments[iexp]->SetBinContent(ibinx+1, r1->Gaus(NvslogENewAll->GetBinContent(ibinx+1), sqrt(NvslogENewAll->GetBinContent(ibinx+1))) );
           else 										    NvslogENewAll_experiments[iexp]->SetBinContent(ibinx+1, r1->Poisson(NvslogENewAll->GetBinContent(ibinx+1)));
       }
    }

    //BEGIN ITERATIONS
    for(iitera = 1; iitera <= nitera; iitera = iitera+jumpstepsitera)
    {
        
    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                                Unfolding experiments


    //Unfolding experiments
        cout << endl << "@ BEGIN UNFOLDING WITH ITERATIONS " << iitera;
        for(iexp = 0; iexp < nexp; iexp++)
        {
      //Create Histogram for experiment
            NvslogENewAll_experiments_unfolded[iexp]->Reset();
    
	 //Initialize seed
        
            for(ibinx = 0; ibinx < nbinx; ibinx++)
            {
                NvslogENewAll_experiments_unfolded[iexp]->SetBinContent(ibinx+1, h1DSeed->GetBinContent(ibinx+1));
            }
      //Unfolding
      //cout << endl << "  Unfolding spectrum " << iexp;
            Unfolding(iitera, NvslogENewAll_experiments[iexp], h2DResponseMatrix, NvslogENewAll_experiments_unfolded[iexp], gEfficiencyvsTrueEnergy);
      //Unfolding(iitera, NvslogENewAll_experiments[iexp], h2DResponseMatrix, NvslogENewAll_experiments_unfolded[iexp]); //para GOLD nuevo
        }


    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                           Calculate statistical uncertainties

    //Declare Average of unfolded experimental spectra
        Double_t  Stat_error_square[500];
        Double_t  N_tru_avrg[500];

    //Initialize vector
        for(ibinx = 0; ibinx < nbinx; ibinx++)
        {
            N_tru_avrg       [ibinx] = 0.0;
            Stat_error_square[ibinx] = 0.0;
        }



    //First STEP: Calculate average of unfolded experimental spectra
        for(ibinx = 0; ibinx < nbinx; ibinx++)
        {
            for(iexp = 0; iexp < nexp; iexp++)
            {
                N_tru_avrg[ibinx] =  N_tru_avrg[ibinx] + NvslogENewAll_experiments_unfolded[iexp]->GetBinContent(ibinx+1);
            }
            N_tru_avrg[ibinx] =  N_tru_avrg[ibinx]/nexp;
        }


    //Second STEP: Calculate statistical error
        for(ibinx = 0; ibinx < nbinx; ibinx++)
        {
            for(iexp = 0; iexp < nexp; iexp++)
            {
                Stat_error_square[ibinx] =  Stat_error_square[ibinx] + (N_tru_avrg[ibinx]  -  NvslogENewAll_experiments_unfolded[iexp]->GetBinContent(ibinx+1))**2;
            }
            Stat_error_square[ibinx] =  Stat_error_square[ibinx]/nexp;
        }


    //Save error into Graph
    gStatError_avrg[icounter] = new TGraph();
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
      gStatError_avrg[icounter]->SetPoint(ibinx, NvslogENewAll->GetBinCenter(ibinx+1), sqrt(Stat_error_square[ibinx]));
    }



    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                                   Unfolding original measured data

    NvslogENewAll_unfolded->Reset();

	//Initialize seed
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
       NvslogENewAll_unfolded->SetBinContent(ibinx+1, h1DSeed->GetBinContent(ibinx+1));
    }

      Unfolding(iitera, NvslogENewAll, h2DResponseMatrix, NvslogENewAll_unfolded, gEfficiencyvsTrueEnergy);
    //Unfolding(iitera, NvslogENewAll, h2DResponseMatrix, NvslogENewAll_unfolded);

    //Set values for bins of experiments
    for(iexp = 0; iexp < nexp; iexp++)
    {
       NvslogENewAll_experiments_unfolded[iexp]->Reset();

       //Fill with random generator
       for(ibinx = 0; ibinx < nbinx; ibinx++)
       {
             if(NvslogENewAll_unfolded->GetBinContent(ibinx+1) > 1e2)  NvslogENewAll_experiments_unfolded[iexp]->SetBinContent(ibinx+1, r1->Gaus(NvslogENewAll_unfolded->GetBinContent(ibinx+1), sqrt(NvslogENewAll_unfolded->GetBinContent(ibinx+1))) );
             else                                                      NvslogENewAll_experiments_unfolded[iexp]->SetBinContent(ibinx+1, r1->Poisson(NvslogENewAll_unfolded->GetBinContent(ibinx+1)));
       }
    }


    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                                   Forward folding the unfolded experiments


    //Unfolding experiments
    //cout << endl << "@ BEGIN FORWARD FOLDING";
    for(iexp = 0; iexp < nexp; iexp++)
    {
      NvslogENewAll_experiments_forwardfolded[iexp]->Reset();


      //Unfolding
      //cout << endl << "  Forward folding spectrum " << iexp;
      Forwardfolding(NvslogENewAll_experiments_unfolded[iexp], h2DResponseMatrix, NvslogENewAll_experiments_forwardfolded[iexp]);
    }




    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                                         Reunfolding the experiments


    //Unfolding experiments
    //cout << endl << "@ BEGIN REUNFOLDING WITH ITERATIONS " << iitera;
    for(iexp = 0; iexp < nexp; iexp++)
    {
      //Create Histogram for experiment
      NvslogENewAll_experiments_reunfolded[iexp]->Reset();

	 //Initialize seed
     for(ibinx = 0; ibinx < nbinx; ibinx++)
     {
       NvslogENewAll_experiments_reunfolded[iexp]->SetBinContent(ibinx+1, h1DSeed->GetBinContent(ibinx+1));
     }

      //Unfolding
      //cout << endl << "  Unfolding spectrum " << iexp;
      //Unfolding(iitera, NvslogENewAll_experiments[iexp], h2DResponseMatrix, NvslogENewAll_experiments_unfolded[iexp], gEfficiencyvsTrueEnergy);
      Unfolding(iitera, NvslogENewAll_experiments_forwardfolded[iexp], h2DResponseMatrix, NvslogENewAll_experiments_reunfolded[iexp], gEfficiencyvsTrueEnergy);
    }





    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                             Calculate systematics uncertainties

    //Declare Average of unfolded experimental spectra
    Double_t  Syst_error[500];

    //Initialize vector
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
      Syst_error[ibinx] = 0.0;
    }

    //FIRST STEP: Calculate systematic error
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
      for(iexp = 0; iexp < nexp; iexp++)
      {
	    Syst_error[ibinx] = Syst_error[ibinx] + (NvslogENewAll_unfolded->GetBinContent(ibinx+1)  -  NvslogENewAll_experiments_reunfolded[iexp]->GetBinContent(ibinx+1));
      }
	  Syst_error[ibinx] =  Syst_error[ibinx]/nexp;
    }

    //Save error into Graph
    gSystError_avrg[icounter] = new TGraph();
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
      gSystError_avrg[icounter]->SetPoint(ibinx, NvslogENewAll->GetBinCenter(ibinx+1), TMath::Abs(Syst_error[ibinx]));
    }




    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //                             Calculate weighted mean squared error


    //Calculation of WMSE
    WMSE = 0.0;
    for(ibinx = ibinx_threshold-1; ibinx < ibinx_maximum; ibinx++)
    {
      if(NvslogENewAll_unfolded->GetBinContent(ibinx+1) > 0)
      {
	     WMSE = WMSE + ((Stat_error_square[ibinx]  + Syst_error[ibinx]**2)/NvslogENewAll_unfolded->GetBinContent(ibinx+1));
      }
    }
    WMSE = WMSE/(ibinx_maximum - ibinx_threshold + 1);

    gWMSE->SetPoint(icounter,iitera,WMSE);



    //Save error into Graph
    gRelativeError_avrg[icounter] = new TGraph();
    for(ibinx = 0; ibinx < nbinx; ibinx++)
    {
      if(NvslogENewAll_unfolded->GetBinContent(ibinx+1) > 0)
      {
	      gRelativeError_avrg[icounter]->SetPoint(ibinx, NvslogENewAll->GetBinCenter(ibinx+1),
					    sqrt(Stat_error_square[ibinx] +  Syst_error[ibinx]**2)/NvslogENewAll_unfolded->GetBinContent(ibinx+1));
      }
      else
      {
          gRelativeError_avrg[icounter]->SetPoint(ibinx, NvslogENewAll->GetBinCenter(ibinx+1), 0.0);
      }
    }


     //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     //      Calculate the deviation between the forwardfolded and mesaured histogram
     Forwardfolding(NvslogENewAll_unfolded, h2DResponseMatrix, NvslogENewAll_forwardfolded);


       Chi2     = 0.0;
       Chi2_ndf = 0.0;
       ndf      = nbinx;
       for(ibinx = ibinx_threshold-1; ibinx < ibinx_maximum; ibinx++)
       {
	 bin_events_ff = NvslogENewAll_forwardfolded->GetBinContent(ibinx+1);
	 bin_events_raw= NvslogENewAll->GetBinContent(ibinx+1);
	 if(bin_events_raw > 0)
	 {
	   Chi2 +=  TMath::Power(bin_events_raw - bin_events_ff, 2)/bin_events_raw;
	 }
	 else
	 {
	   if(bin_events_ff > 0) Chi2 +=  TMath::Power(bin_events_raw - bin_events_ff, 2)/bin_events_ff;
	 }

	 if(bin_events_raw == 0 && bin_events_ff == 0) ndf--;
       }
       Chi2_ndf = Chi2/ndf;

       Chi2_vs_iterations->SetPoint(icounter, iitera, Chi2_ndf);
       //cout << Chi2_ndf << endl;


    //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    //      Calculate the relative error between the forwardfolded and mesaured histogram


    relative_error = 0.0;

    for(ibinx = ibinx_threshold-1; ibinx < ibinx_maximum; ibinx++)
    {
      bin_events_ff = NvslogENewAll_forwardfolded->GetBinContent(ibinx+1);
      bin_events_raw= NvslogENewAll->GetBinContent(ibinx+1);
      if(bin_events_raw > 0)
      {
        relative_error +=  abs(bin_events_raw - bin_events_ff)/bin_events_raw;
      }
      else
      {
        if(bin_events_ff > 0) relative_error +=  abs(bin_events_raw - bin_events_ff)/bin_events_ff;
      }


    }


    RelativeError_vs_iterations->SetPoint(icounter, iitera, relative_error);



     //%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
     icounter++;

    }//END ITERATIONS




//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                                       Plot years_and_years graph

     Char_t  Title[100];


     sprintf(Title, "HAWC: log_{10}(E^{th}/GeV) = %.1f", logEGeV_threshold);



     TCanvas *CanvasWMSE  = new TCanvas("CanvasWMSE", "WMSE",650,0,600,500);
     CanvasWMSE ->SetFillColor(10);
     CanvasWMSE ->SetFrameFillColor(10);
     CanvasWMSE ->SetLogx(0);
     CanvasWMSE ->SetLogy(1);
     CanvasWMSE->Range(-2.032855,2469.293,11.4623,4359.211);
     CanvasWMSE->SetLeftMargin(0.158046);
     CanvasWMSE->SetRightMargin(0.04166667);
     CanvasWMSE->SetTopMargin(0.07838983);
     CanvasWMSE->SetBottomMargin(0.1228814);


     CanvasWMSE->cd();
     gWMSE->SetTitle(0);
     gWMSE->SetMarkerColor(colorMark[0]);
     gWMSE->SetLineColor(colorMark[0]);
     gWMSE->SetMarkerStyle(styleMark[0]);
     gWMSE->SetMarkerSize(1.2);
     gWMSE->SetLineWidth(1);
     gWMSE->GetXaxis()->SetTitle("Number of iterations");
     gWMSE->GetYaxis()->SetTitle("Weighted Mean Squared Error");
     gWMSE->GetXaxis()->SetLabelSize(0.05);
     gWMSE->GetYaxis()->SetLabelSize(0.05);
     gWMSE->GetXaxis()->SetTitleSize(0.05);
     gWMSE->GetYaxis()->SetTitleSize(0.05);
     gWMSE->GetXaxis()->SetTitleOffset(1.00);
     gWMSE->GetYaxis()->SetTitleOffset(1.40);
     gWMSE->Draw("APE");

     TPaveLabel *pt = new TPaveLabel(0.63,0.85,0.93,0.91,"","brNDC");
     pt->SetLabel(Title);
     pt->Draw();
     CanvasWMSE->Modified();



     TCanvas *CanvasChi2ndf  = new TCanvas("CanvasChi2ndf", "Chi2ndf",650,0,600,500);
     CanvasChi2ndf ->SetFillColor(10);
     CanvasChi2ndf ->SetFrameFillColor(10);
     CanvasChi2ndf ->SetLogx(0);
     CanvasChi2ndf ->SetLogy(1);
     CanvasChi2ndf->Range(-2.032855,2469.293,11.4623,4359.211);
     CanvasChi2ndf->SetLeftMargin(0.158046);
     CanvasChi2ndf->SetRightMargin(0.04166667);
     CanvasChi2ndf->SetTopMargin(0.07838983);
     CanvasChi2ndf->SetBottomMargin(0.1228814);


     CanvasChi2ndf->cd();
     Chi2_vs_iterations->SetTitle(0);
     Chi2_vs_iterations->SetMarkerColor(colorMark[0]);
     Chi2_vs_iterations->SetLineColor(colorMark[0]);
     Chi2_vs_iterations->SetMarkerStyle(styleMark[0]);
     Chi2_vs_iterations->SetMarkerSize(1.2);
     Chi2_vs_iterations->SetLineWidth(1);
     Chi2_vs_iterations->GetXaxis()->SetTitle("Number of iterations");
     Chi2_vs_iterations->GetYaxis()->SetTitle("#Chi^{2}/n_{dof}");
     Chi2_vs_iterations->GetXaxis()->SetLabelSize(0.05);
     Chi2_vs_iterations->GetYaxis()->SetLabelSize(0.05);
     Chi2_vs_iterations->GetXaxis()->SetTitleSize(0.05);
     Chi2_vs_iterations->GetYaxis()->SetTitleSize(0.05);
     Chi2_vs_iterations->GetXaxis()->SetTitleOffset(1.00);
     Chi2_vs_iterations->GetYaxis()->SetTitleOffset(1.40);
     Chi2_vs_iterations->Draw("APE");


     TCanvas *CanvasRelativeError  = new TCanvas("CanvasRelativeError", "RelativeError",650,0,600,500);
     CanvasRelativeError ->SetFillColor(10);
     CanvasRelativeError ->SetFrameFillColor(10);
     CanvasRelativeError ->SetLogx(0);
     CanvasRelativeError ->SetLogy(0);
     CanvasRelativeError->Range(-2.032855,2469.293,11.4623,4359.211);
     CanvasRelativeError->SetLeftMargin(0.158046);
     CanvasRelativeError->SetRightMargin(0.04166667);
     CanvasRelativeError->SetTopMargin(0.07838983);
     CanvasRelativeError->SetBottomMargin(0.1228814);


     CanvasRelativeError->cd();
     RelativeError_vs_iterations->SetTitle(0);
     RelativeError_vs_iterations->SetMarkerColor(colorMark[0]);
     RelativeError_vs_iterations->SetLineColor(colorMark[0]);
     RelativeError_vs_iterations->SetMarkerStyle(styleMark[0]);
     RelativeError_vs_iterations->SetMarkerSize(1.2);
     RelativeError_vs_iterations->SetLineWidth(1);
     RelativeError_vs_iterations->GetXaxis()->SetTitle("Number of iterations");
     RelativeError_vs_iterations->GetYaxis()->SetTitle("Relative Error");
     RelativeError_vs_iterations->GetXaxis()->SetLabelSize(0.05);
     RelativeError_vs_iterations->GetYaxis()->SetLabelSize(0.05);
     RelativeError_vs_iterations->GetXaxis()->SetTitleSize(0.05);
     RelativeError_vs_iterations->GetYaxis()->SetTitleSize(0.05);
     RelativeError_vs_iterations->GetXaxis()->SetTitleOffset(1.00);
     RelativeError_vs_iterations->GetYaxis()->SetTitleOffset(1.40);
     RelativeError_vs_iterations->Draw("APE");

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
//                                             Save Graphs


  Int_t  nSaveRootFile = 0;
  Char_t NameRootFileSave[600];
  Char_t NameObject[600];

  cout << endl << "@ Save Root File 0) No   1) Yes? ";
  cin  >> nSaveRootFile;

  if(nSaveRootFile == 1)
  {
    //ROOT FILE
    //cout << "@ Write name of the Root File: ";
    //cin >> NameRootFileSave;

    if(nMC == 0)
    {
      sprintf(NameRootFileSave,"%s/WeightedErrors_Unfold_Zeg%d_Mass%d_Cut_%s_Exp_ObtainMass%d_AgevsEnergy_FullStat_logEGeV_%.1f_%.1f_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, ncutMassToReconstruct, logEGeV_threshold, logEGeV_maximum);
    }
    else
    {
      sprintf(NameRootFileSave,"%s/WeightedErrors_Unfold_Zeg%d_Mass%d_Cut_%s_MC_ObtainMass%d_AgevsEnergy_logEGeV_%.1f_%.1f_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, ncutMassToReconstruct, logEGeV_threshold, logEGeV_maximum);
    }
    TFile FSave(NameRootFileSave,"RECREATE");

    if(CanvasWMSE  != NULL)FSave.WriteTObject(CanvasWMSE, "CanvasWMSE");
    if(gWMSE       != NULL)gWMSE->Write("gWMSE");

    for(iitera = 0; iitera < icounter; iitera++)
    {
      sprintf(NameObject, "gStatError_avrg%d", iitera);
      if(gStatError_avrg[iitera] != NULL)gStatError_avrg[iitera]->Write(NameObject);
      sprintf(NameObject, "gSystError_avrg%d", iitera);
      if(gSystError_avrg[iitera] != NULL)gSystError_avrg[iitera]->Write(NameObject);
      sprintf(NameObject, "gRelativeError_avrg%d", iitera);
      if(gRelativeError_avrg[iitera] != NULL)gRelativeError_avrg[iitera]->Write(NameObject);
    }

    if(CanvasChi2ndf      != NULL)FSave.WriteTObject(CanvasChi2ndf, "CanvasChi2ndf");
    if(Chi2_vs_iterations != NULL)Chi2_vs_iterations->Write("Chi2_vs_iterations");

    FSave.Close();
  }

}
