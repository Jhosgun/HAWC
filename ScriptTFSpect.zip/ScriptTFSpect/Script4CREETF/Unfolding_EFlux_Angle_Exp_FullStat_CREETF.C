/**
 * @Author: J.A.M.S. <jorge-moralesas>
 * @Date:   2020-04-13T19:20:07-05:00
 * @Email:  jorge.morales@umich.mx
 * @Last modified by:   jorge-moralesas
 * @Last modified time: 2024-02-18T12:29:53-06:00
 */




{
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                           Clean Memory

    gDirectory->DeleteAll();
    gROOT->Reset();
    gROOT->cd();


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                               Load cuts

    gROOT->ProcessLine(".x ./MyCuts_DQB_paper_CREETF.C");


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    cout << endl << "+++++++++++++++++++++++ Experimental HAWC data +++++++++++++++++++++++++";
    cout << endl;


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Define variables

    //Zenith Angle and Primary type
    Int_t    ncutZenith  = 3;
    Int_t    ncutMass    = 0;
    Int_t    nUnfolding  = 0;
    Int_t    nIterations = 1;
    Int_t    nCutAge_vs_logEnergy = 0;
    Int_t    ncutMassToReconstruct = 0;

    //Factor of weight for events
    Double_t WeightFactor = 32168.6;

    //Energy spectrum
    Int_t    ibinx = 0, nbinx = 22;
    Double_t Gamma_Index = 2.6;
    Double_t E_Set[50], logE_Set[50];
    Double_t NeventsE_Set[50], DNeventsE_Set[50];
    Double_t DlogE_Set[50], DlogEhalf_Set[50], DE_Set[50], DEhalf_Set[50];
    Double_t FluxE_Set [50], DFluxE_Set [50];
    Double_t FluxE1_Set[50], DFluxE1_Set[50];
    Double_t FluxEGamma_Set[50], DFluxEGamma_Set[50];
    Double_t Aream2 = 22e3*pow(1.0,2.0);
    //Double_t DtSec_5481 = 32168.6;
    //Double_t DtSec = 117986472.7; //todas las corridas
    //Double_t DtSec = 172868.95;
    //Double_t  DtSec = 2.57725e+06; //one month
    //Double_t  DtSec =  6.07674e+07;  //two years (2018-2019)
    //Double_t DtSec = 244710; //Este es el tiempo para las corridas z0
    Double_t DtSec = 32169.0; //run5481
    //Double_t DtSec = 9.55517e+06; //tiempo muestra Jan-Apr 2017
    //Double_t DtSec = 1.66946e+08;  //tiempo 5 años Junio 2015 - Diciembre 2020  /// tiempo integrado segundos 32169
    //Double_t DtSec = 41848;
    //Double_t DtSec = 6.076795e+07;  //tiempo 2 años Junio 2018 - Diciembre 2019
    //Double_t DtSec = 9.179887e+07;  //tiempo 3 años Junio 2018 - Diciembre 2020
    //Double_t DtSec = 1*WeightFactor;
    Double_t  logEGeV_minimum = 2.0;
    Double_t  logEGeV_maximum = 6.4;


    //Variable for Cuts
    TCut MyCuts;

    //List
    Int_t   nev_List, iev_List, iev_Root;
    TEntryList *temp_List = NULL;
    TEntryList *ListALL   = NULL;
    Char_t      nameListAll[30];


    //Classify event according to mass composition
    Long64_t Classififed_Mass = 0;


    //Plotting Style
    Int_t  colorMark[12] = { 1, 2, 4, 8, 6, 41,50,25,28,36, 3, 5};
    Int_t  styleMark[12] = {20,22,25,26,24,27,20,22,25,26, 20, 20};


    //Weight
    Double_t Weight_TOTAL = 1.0;

    Char_t  DIROUT[60];
    sprintf(DIROUT, "CREETF_JCCUTS");
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                      Choose parameters

    cout << endl << "Unfolding of mass group energy spectra using CREAM-II model"<< endl;
    cout << endl << "0) No cut   1) Light (cut at He)  2) Light (cut mid He&C)  3) Light (cut at C)   4) H (cut at H)  5) Z>1 (cut at He)  6) Z>2 (cut mid He&C): ";
    cin  >> nCutAge_vs_logEnergy;

    Char_t  nameFile_nCutAge_vs_logEnergy[60];
    Char_t  namePlot_nCutAge_vs_logEnergy[60];
    switch(nCutAge_vs_logEnergy)
    {
        case 0:
            sprintf(nameFile_nCutAge_vs_logEnergy, "noMassCut");
            sprintf(namePlot_nCutAge_vs_logEnergy, "All Nuclei");
            ncutMassToReconstruct = 0;
            break;
        case 1:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 2:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 3:
            sprintf(nameFile_nCutAge_vs_logEnergy, "light_at_C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Light");
            ncutMassToReconstruct = 9;
            break;
        case 4:
            sprintf(nameFile_nCutAge_vs_logEnergy, "H_at_H");
            sprintf(namePlot_nCutAge_vs_logEnergy, "H");
            ncutMassToReconstruct = 1;
            break;
        case 5:
            sprintf(nameFile_nCutAge_vs_logEnergy, "Heavy_at_He");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 11;
            break;
        case 6:
            sprintf(nameFile_nCutAge_vs_logEnergy, "heavy_at_mid_He-C");
            sprintf(namePlot_nCutAge_vs_logEnergy, "Heavy");
            ncutMassToReconstruct = 10;
            break;
    }

    //cout << endl << "Select the zenith angle interval (deg)";
    cout << endl << "The zenith angle interval (deg)";
    cout << endl << "0)[   0,16.7] : ";
    //cin  >> ncutZenith;
    ncutZenith=0;


    cout << endl << "Apply unfolding procedure to all-particle spectrum [no(0)  yes(1)] :";
    cin  >> nUnfolding;


    if(nUnfolding == 1)
    {
        cout << endl << "How many iterations? ";
        cin  >> nIterations;

        cout << endl << "Mass To Reconstruct";
        cout << endl << legendcutMass[ncutMassToReconstruct] << endl;
    }


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Define Canvas


    cHistogram = new TCanvas("cHistogram","Energy histogram",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cHistogram->Clear();
    cHistogram->SetGridx(0);
    cHistogram->SetGridy(0);
    cHistogram->SetBorderMode(0);


    cFlux = new TCanvas("cFlux","MC Rec Energy spectrum",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cFlux->Clear();
    cFlux->SetGridx(0);
    cFlux->SetGridy(0);
    cFlux->SetBorderMode(0);


    cFluxE1 = new TCanvas("cFluxE1","MC Rec Energy spectrum x E",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cFluxE1->Clear();
    cFluxE1->SetGridx(0);
    cFluxE1->SetGridy(0);
    cFluxE1->SetBorderMode(0);


    cFluxEGamma = new TCanvas("cFluxEGamma","MC Rec Energy spectrum x E**Gamma",650,0,600,500);
    gPad ->SetGrid();
    gPad ->SetFillColor(10);
    gPad ->SetFrameFillColor(10);
    gPad ->SetLogx(0);
    gPad ->SetLogy(1);
    gPad->SetLeftMargin(0.15);
    gPad->SetRightMargin(0.05);
    gPad->SetTopMargin(0.07);
    gPad->SetBottomMargin(0.13);
    cFluxEGamma->Clear();
    cFluxEGamma->SetGridx(0);
    cFluxEGamma->SetGridy(0);
    cFluxEGamma->SetBorderMode(0);


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Define Histograms

    TH1D   *hFlux[maxcutMass];
    TH2D   *h2DResponseMatrixRecvsTrue[maxcutMass];
    Char_t  namehFlux[maxcutMass][30];
    Char_t  nameh2DResponseMatrixRecvsTrue[maxcutMass][30];
    for(icutMass = 0; icutMass < maxcutMass; icutMass++)
    {
      sprintf(namehFlux[icutMass], "hFlux%d", icutMass);
      hFlux[icutMass] = new TH1D(namehFlux[icutMass], namehFlux[icutMass], nbinx, logEGeV_minimum, logEGeV_maximum);
    }


    TGraphErrors *FluxvslogE     [maxcutMass];
    TGraphErrors *FluxvslogE1    [maxcutMass];
    TGraphErrors *FluxvslogEGamma[maxcutMass];
    TGraphErrors *FluxvsEGamma   [maxcutMass];

    TF1 *powerlaw = new TF1("powerlaw", "[0]*pow(10.0, x)**[1]", logEGeV_minimum,logEGeV_maximum);
    powerlaw->SetParameters(2e-16, -1.5);


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                         Open Root files
    Char_t rootfileEnergy[300];
    sprintf(rootfileEnergy,"./%s/histogram_run005481.root",DIROUT);
    //Open file
    //TFile RootFile_EnergyCalibration_MC ("/Users/jorge-moralesas/HAWC/Analisis/tests/setsNew_Algorithm/New_Algorithm_data.root");
    //TFile RootFile_EnergyCalibration_MC ("~/HAWC/Analisis/tests/sets/set_two_years.root");
    //TFile RootFile_EnergyCalibration_MC ("~/HAWC/Analisis/tests/sets/z0.root");
    TFile RootFile_EnergyCalibration_MC (rootfileEnergy);
    //TFile RootFile_EnergyCalibration_MC ("/Users/jorge-moralesas/HAWC/Analisis/tests/sets/Bin22_35deg_3Years_All_lowEnergyCut.root");
    //TFile RootFile_EnergyCalibration_MC ("~/Documents/doctorado/root_files/energy_histograms/bin22/2016/6/set_run005480_inclinados.root");


    //TFile RootFile_EnergyCalibration_MC ("/Users/jorge-moralesas/HAWC/Analisis/tests/sets/Bin22_35deg_5Years_zenith0_lowEnergyCut.root");

    switch(nCutAge_vs_logEnergy)
    {
        case 0:
        hFlux[ncutMass] = (TH1D*)gDirectory->Get("histogram_recEnergy");
            break;
        case 1:
	    hFlux[ncutMass] = (TH1D*)gDirectory->Get("hFlux_light_at_He");
            break;
        case 2:
	    hFlux[ncutMass] = (TH1D*)gDirectory->Get("hFlux_light_at_mid_He_C");
            break;
        case 3:
	    hFlux[ncutMass] = (TH1D*)gDirectory->Get("hFlux_light_at_C");
            break;
        case 4:
	    hFlux[ncutMass] = (TH1D*)gDirectory->Get("hFlux_light_at_H");
            break;
        case 5:
	    hFlux[ncutMass] = (TH1D*)gDirectory->Get("hFlux_heavy_at_He");
            break;
        case 6:
	    hFlux[ncutMass] = (TH1D*)gDirectory->Get("hFlux_heavy_at_mid_He_C");
            break;
    }
    //hFlux[ncutMass]->Rebin(2);


//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                 Select and Work out data



    if(nUnfolding == 1)
    {

        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        //Here we apply the unfolding using the Bayesian Algorithm
        Char_t name_ROOTFile_ResponseMatrixRecvsTrue[300];
	    sprintf(name_ROOTFile_ResponseMatrixRecvsTrue,"%s/Plot_RawEFlux_Zeg%d_Mass%d_Cut_%s_MC_Bin22_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, ncutMassToReconstruct);

        TFile ROOTFile_ResponseMatrixRecvsTrue(name_ROOTFile_ResponseMatrixRecvsTrue);
        Char_t name_h2DResponseMatrixRecvsTrue_mixed[300];
        sprintf(name_h2DResponseMatrixRecvsTrue_mixed,"h2DResponseMatrixRecvsTrue_Zeg%d_Mass%d", ncutZenith, ncutMass);
        h2DResponseMatrixRecvsTrue_mixed = (TH2D*)gDirectory->Get(name_h2DResponseMatrixRecvsTrue_mixed);
        hFluxunfold     =  (TH1D*)gDirectory->Get("HistogramTrue_Zeg0_Mass0");

        //@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
        //Read Efficiency plot for Unfolding
        Char_t name_ROOTFILE_EfficiencyvsTrueEnergy [300];
        Char_t name_gEfficiencyvsTrueEnergy         [300];

	    sprintf(name_ROOTFILE_EfficiencyvsTrueEnergy, "%s/newEA_Plot_EffArea_Zeg%d_Mass%d_Cut_%s_Bin22_MC_ObtainMass%d_AgevsEnergy_DQB.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, ncutMassToReconstruct);
        TFile ROOTFile_EfficiencyvsTrueEnergy(name_ROOTFILE_EfficiencyvsTrueEnergy);
        sprintf(name_gEfficiencyvsTrueEnergy, "gEffective_Area_m2_Smoothed_Zeg%d_Mass%d", ncutZenith, ncutMassToReconstruct);
        gEfficiencyvsTrueEnergy = (TGraphErrors*)gDirectory->Get(name_gEfficiencyvsTrueEnergy);

        //gROOT->ProcessLine(".L ~/HAWC/Analisis/tests/lib/Subroutine_Bayesian_plus_efficiency_nosmoothroot_v4.c"); //Esta es la que uso como resultado estandar.

        gROOT->ProcessLine(".L ../Lib/smoothing_v4.c");
        //gROOT->ProcessLine(".L ~/HAWC/Analisis/tests/lib/Subroutine_Bayesian_plus_efficiency_nosmoothroot_v5.c");
        //gROOT->ProcessLine(".L ~/HAWC/Analisis/tests/lib/Subroutine_Bayesian_plus_efficiency_nosmoothroot_v6.c");
        //gROOT->ProcessLine(".L ~/HAWC/Analisis/tests/lib/Markov_v2.c");

        Unfolding(nIterations, hFlux[ncutMass], h2DResponseMatrixRecvsTrue_mixed, hFluxunfold, gEfficiencyvsTrueEnergy);

        for(ibinx = 0; ibinx < nbinx; ibinx++)
        {
            hFlux[ncutMass]->SetBinContent(ibinx+1, hFluxunfold->GetBinContent(ibinx+1));
        }

    }//End unfolding


    //Energy spectrum
      for(ibinx = 0; ibinx < nbinx; ibinx++)
      {
    	//Fill E spectra
        logE_Set      [ibinx] = hFlux[ncutMass]->GetBinCenter(ibinx+1)+0.01;
        E_Set         [ibinx] =  pow(10, logE_Set[ibinx]);
        DlogE_Set     [ibinx] = hFlux[ncutMass]->GetBinWidth (ibinx+1);
        NeventsE_Set  [ibinx] = hFlux[ncutMass]->GetBinContent(ibinx+1);
        DE_Set        [ibinx] =  pow(10, logE_Set[ibinx] + DlogE_Set[ibinx]/2)
                                -pow(10, logE_Set[ibinx] - DlogE_Set[ibinx]/2);
        DNeventsE_Set [ibinx] =  0.0;

        //Efficiency correction
        Double_t Eff = 1.0;
        if(nUnfolding == 1)
        {
           if(logE_Set[ibinx] >= 6.0)  { Eff = gEfficiencyvsTrueEnergy->Eval(logE_Set[ibinx]);}
           else                        { Eff = gEfficiencyvsTrueEnergy->Eval(logE_Set[ibinx]);}
           if(Eff == 0) {Eff = 1.0;NeventsE_Set[ibinx] = 0.0;}
        }


        //Muon number spectrum  in units of m^-2 s^-1 sr^-1
        FluxE_Set    [ibinx]  =   NeventsE_Set[ibinx]/DE_Set[ibinx];
          if(nUnfolding == 1)
          {
              FluxE_Set    [ibinx]  =   FluxE_Set[ibinx]/(DOmegaSr[ncutZenith]*DtSec*Eff);
              DFluxE_Set   [ibinx]  =   sqrt(NeventsE_Set[ibinx])/DE_Set[ibinx];
              DFluxE_Set   [ibinx]  =   DFluxE_Set[ibinx]/(DOmegaSr[ncutZenith]*DtSec*Eff);
          }
          else
          {
              FluxE_Set    [ibinx]  =   FluxE_Set[ibinx]/(Aream2*DOmegaSrCosef[ncutZenith]*DtSec*Eff);
              DFluxE_Set   [ibinx]  =   sqrt(NeventsE_Set[ibinx])/DE_Set[ibinx];
              DFluxE_Set   [ibinx]  =   DFluxE_Set[ibinx]/(Aream2*DOmegaSrCosef[ncutZenith]*DtSec*Eff);
          }


          cout << endl;
          cout << ibinx << ")   EnergyBinUpp: " <<  pow(10, logE_Set[ibinx] - DlogE_Set[ibinx]/2) << ",   Flux (w/o energy factor): " << FluxE_Set[ibinx] << endl;




        DlogEhalf_Set[ibinx]  =   DlogE_Set[ibinx]*0.0/2.0;
        DEhalf_Set   [ibinx]  =   0.0;

        //Muon number spectrum  x Nmu in units of m^-2 s^-1 sr^-1
        FluxE1_Set  [ibinx]  =   FluxE_Set[ibinx]*E_Set[ibinx];
        DFluxE1_Set [ibinx]  =   DFluxE_Set[ibinx]*E_Set[ibinx];

        //Muon number spectrum  x Nmu in units of m^-2 s^-1 sr^-1
        FluxEGamma_Set [ibinx]=  FluxE_Set[ibinx] *pow(E_Set[ibinx], Gamma_Index);
        DFluxEGamma_Set[ibinx]=  DFluxE_Set[ibinx]*pow(E_Set[ibinx], Gamma_Index);

      }
      FluxvslogE     [ncutMass] = new TGraphErrors(nbinx, logE_Set, FluxE_Set, DlogEhalf_Set, DFluxE_Set);
      FluxvslogE1    [ncutMass] = new TGraphErrors(nbinx, logE_Set, FluxE1_Set, DlogEhalf_Set, DFluxE1_Set);
      FluxvslogEGamma[ncutMass] = new TGraphErrors(nbinx, logE_Set, FluxEGamma_Set, DlogEhalf_Set, DFluxEGamma_Set);
      FluxvsEGamma   [ncutMass] = new TGraphErrors(nbinx, E_Set, FluxEGamma_Set, DEhalf_Set, DFluxEGamma_Set);



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                       Plot data

      TPaveLabel *ptext = new TPaveLabel(0.7123746,0.8610526,0.9280936,0.9094737,legendcutZenith[ncutZenith],"brNDC");
      ptext->SetLineColor(kWhite);
      ptext->SetFillColor(0);
      ptext->SetShadowColor(0);
      ptext->SetTextSize(0.7826087);


      TPaveLabel *pl = new TPaveLabel(0.7508361,0.7957895,0.8963211,0.8442105,"HAWC: raw data","brNDC");
      pl->SetFillColor(0);
      pl->SetLineColor(0);
      pl->SetTextSize(0.7826087);


      pl2 = new TPaveLabel(0.7558528,0.7326316,0.9013378,0.7810526,"Light events","brNDC");
      pl2->SetFillColor(0);
      pl2->SetLineColor(0);
      pl2->SetTextColor(kAzure+1);
      pl2->SetTextSize(0.7826087);


      cHistogram->cd();
      hFlux[ncutMass]->SetTitle(0);
      hFlux[ncutMass]->SetStats(kFALSE);
      hFlux[ncutMass]->SetMaximum(1e9);
      hFlux[ncutMass]->SetMinimum(1e6);
      hFlux[ncutMass]->SetMarkerStyle(20);

      hFlux[ncutMass]->SetMarkerColor(colorMark[ncutMass]);
      hFlux[ncutMass]->SetLineColor(colorMark[ncutMass]);
      hFlux[ncutMass]->SetFillColor(kAzure+1);
      hFlux[ncutMass]->GetXaxis()->SetTitle("log_{10}(E^{r}/GeV)");
      hFlux[ncutMass]->GetYaxis()->SetTitle("Events");
      hFlux[ncutMass]->GetXaxis()->SetTitleSize(0.05);
      hFlux[ncutMass]->GetYaxis()->SetTitleSize(0.05);
      hFlux[ncutMass]->GetYaxis()->SetLabelSize(0.04);
      hFlux[ncutMass]->GetXaxis()->SetLabelSize(0.04);
      hFlux[ncutMass]->Draw("");
      pl->Draw("same");
      pl2->Draw("same");
      ptext->Draw("same");

      cFlux->cd();
      FluxvslogE[ncutMass]->SetTitle(0);
      FluxvslogE[ncutMass]->SetMaximum(1e-3);
      FluxvslogE[ncutMass]->SetMinimum(1e-15);
      FluxvslogE[ncutMass]->SetMarkerStyle(20);
      FluxvslogE[ncutMass]->SetMarkerColor(colorMark[ncutMass]);
      FluxvslogE[ncutMass]->SetLineColor(colorMark[ncutMass]);
      FluxvslogE[ncutMass]->GetXaxis()->SetTitle("log_{10}(E/GeV)");
      FluxvslogE[ncutMass]->GetYaxis()->SetTitle("d#Phi/dE [m^{-2} s^{-1} sr^{-1} GeV^{-1}]");
      FluxvslogE[ncutMass]->GetXaxis()->SetTitleSize(0.05);
      FluxvslogE[ncutMass]->GetYaxis()->SetTitleSize(0.05);
      FluxvslogE[ncutMass]->Draw("AP");

      powerlaw->SetParameters(1e7, -1.5);
      //FluxvslogE[ncutMass]->Fit("powerlaw","+","",4.5,5.5);




      cFluxE1->cd();
      FluxvslogE1[ncutMass]->SetTitle(0);
      FluxvslogE1[ncutMass]->SetMaximum(1);
      FluxvslogE1[ncutMass]->SetMinimum(1e-9);
      FluxvslogE1[ncutMass]->SetMarkerStyle(20);
      FluxvslogE1[ncutMass]->SetMarkerColor(colorMark[ncutMass]);
      FluxvslogE1[ncutMass]->SetLineColor(colorMark[ncutMass]);
      FluxvslogE1[ncutMass]->GetXaxis()->SetTitle("log_{10}(E/GeV)");
      FluxvslogE1[ncutMass]->GetYaxis()->SetTitle("E d#Phi/dE [m^{-2}  s^{-1} sr^{-1}]");
      FluxvslogE1[ncutMass]->GetXaxis()->SetTitleSize(0.05);
      FluxvslogE1[ncutMass]->GetYaxis()->SetTitleSize(0.05);
      FluxvslogE1[ncutMass]->Draw("AP");




      cFluxEGamma->cd();
      FluxvslogEGamma[ncutMass]->SetTitle(0);
      FluxvslogEGamma[ncutMass]->SetMaximum(5e4);
      FluxvslogEGamma[ncutMass]->SetMinimum(1e2);
      FluxvslogEGamma[ncutMass]->GetXaxis()->SetRangeUser(3.5, 6.0);
      FluxvslogEGamma[ncutMass]->SetMarkerStyle(20);
      FluxvslogEGamma[ncutMass]->SetMarkerColor(colorMark[ncutMass]);
      FluxvslogEGamma[ncutMass]->SetLineColor(colorMark[ncutMass]);
      FluxvslogEGamma[ncutMass]->GetXaxis()->SetTitle("log_{10}(E/GeV)");
      FluxvslogEGamma[ncutMass]->GetYaxis()->SetTitle("E^{2.6} d#Phi/dE [m^{-2} s^{-1} sr^{-1} GeV^{1.6}]");
      FluxvslogEGamma[ncutMass]->GetXaxis()->SetTitleSize(0.05);
      FluxvslogEGamma[ncutMass]->GetYaxis()->SetTitleSize(0.05);
      FluxvslogEGamma[ncutMass]->Draw("AP");



//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//                             Save plots in Root File

    Int_t    nsave=0;
    Char_t   nameRootFile[400];
    Char_t   nameObject[400][400];

    cout << endl << "Save CANVAS in root file? 0) No  1) Yes: ";
    cin  >> nsave;


    if(nsave == 1)
    {

        if(nUnfolding == 0)
        {
	  sprintf(nameRootFile, "%s/Plot_RawEFlux_Zeg%d_Mass%d_Cut_%s_Exp_Bin%d_ObtainMass%d_AgevsEnergy_FullStat_DQB_5481.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);
        }
        else
        {
	  sprintf(nameRootFile, "%s/Plot_UnfoldEFlux_Zeg%d_Mass%d_Cut_%s_Exp_Bin%d_ObtainMass%d_AgevsEnergy_FullStat_DQB_5481.root", DIROUT, ncutZenith, ncutMass, nameFile_nCutAge_vs_logEnergy, nbinx, ncutMassToReconstruct);
        }
       TFile FSave(nameRootFile,"RECREATE");
       FSave.cd();

       FSave.WriteTObject(cFlux);
       sprintf(nameObject[ncutMass], "FluxvslogE_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvslogE[ncutMass]->Write(nameObject[ncutMass]);


       FSave.WriteTObject(cFluxE1);
       sprintf(nameObject[ncutMass], "FluxvslogE1_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvslogE1[ncutMass]->Write(nameObject[ncutMass]);


       FSave.WriteTObject(cFluxEGamma);
       sprintf(nameObject[ncutMass], "FluxvslogEGamma_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvslogEGamma[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "FluxvsEGamma_Zeg%d_Mass%d", ncutZenith, ncutMass);
       FluxvsEGamma[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "Histogram_Zeg%d_Mass%d", ncutZenith, ncutMass);
       hFlux[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "hFlux_Zeg%d_Mass%d", ncutZenith, ncutMass);
       hFlux[ncutMass]->Write(nameObject[ncutMass]);

       sprintf(nameObject[ncutMass], "h%d", ncutMass);
       hFlux[ncutMass]->Write(nameObject[ncutMass]);
       FSave.Close();

       FSave.Close();
     }

 }
