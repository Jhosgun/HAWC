/**
 * @Author: J.A.M.S. <jorge-moralesas>
 * @Date:   2020-04-19T15:43:35-05:00
 * @Email:  jorge.morales@umich.mx
 * @Last modified by:   jorge-moralesas
 * @Last modified time: 2022-05-19T20:51:02-05:00
 */



//overall spectral index do not affect
{
     #include <iostream.h>

     //Global variables
     Double_t const pi = TMath::Pi();
     Char_t   mycutexpression[200];


     //Openning
     cout << "Loading Mycuts HAWC Analysis version February 2019 ...." << endl;


     //Cut over Hits after std selection, 0 or 1 channel −1
     TCut mycutnHit = "rec.nHit>=75";


     //Cut over Fiducial Area Scale
//    TCut mycutcoreFiduScale = "0<=rec.coreFiduScale && rec.coreFiduScale <= 150";
    TCut mycutcoreFiduScale = "0<=rec.coreFiduScale";


     //Cut over Core fit status (0==good)
     TCut mycutcoreFitStatus = "rec.coreFitStatus == 0";


     //Cut over Angle fit status (0==good)
     TCut mycutangleFitStatus = "rec.angleFitStatus == 0";


     //Cut over Max deposited energy at a specific distance
    TCut mycutCxPE40 = "rec.CxPE40XnCh >= 40 && 1.0*rec.nHit/rec.nChAvail>=0.2 && 1.0*rec.nChAvail>0.0";
    //TCut mycutCxPE40 = "rec.CxPE40XnCh >= 20 && 1.0*rec.nHit/rec.nChAvail>=0.2 && 1.0*rec.nChAvail>0.0&& rec.CxPE40 > 50";
    //TCut mycutCxPE40 = "1.0*rec.nHit/rec.nChAvail>=0.2 && 1.0*rec.nChAvail>0.0";
    //TCut Testcut= "!(rec.mlout>6&&800<=rec.nHit)";
    //TCut Testcut= "!(rec.tfout>6&&800<=rec.nHit)";

    //Composition
    Int_t    icutMass;
    Int_t    const maxcutMass=12;
    Int_t    const cutMass[maxcutMass] = {0, 14, 402, 1206, 1608, 2010, 2412, 2814, 5626, 208, 2612, 2297};
    Char_t   legendcutMass[maxcutMass][20] ={"All", "H", "He", "C", "0", "Ne", "Mg", "Si", "Fe", "H+He", "Z #geq 3", "Z #geq 2"};

    TCut mycutMass[maxcutMass]={"mc.corsikaParticleId > 0"   , "mc.corsikaParticleId ==  14", "mc.corsikaParticleId == 402",
				"mc.corsikaParticleId ==1206", "mc.corsikaParticleId ==1608", "mc.corsikaParticleId ==2010",
				"mc.corsikaParticleId ==2412", "mc.corsikaParticleId ==2814", "mc.corsikaParticleId ==5626",
				"mc.corsikaParticleId <= 402", "mc.corsikaParticleId >  402", "mc.corsikaParticleId >= 402"};

    //Zenith angle intervals
    Int_t    icutz=0;
    Int_t    const maxcutz = 1;
    Double_t const thetadeg_MIN = 0.0;
    Double_t const thetadeg_MAX = 35.0;
    Double_t const DOmegaSrMAX_MIN      =  -2*pi*( cos(thetadeg_MAX*pi/180) - cos(thetadeg_MIN*pi/180) );
    Double_t const DOmegaSrCosefMAX_MIN =  -pi*( cos(2*thetadeg_MAX*pi/180) - cos(2*thetadeg_MIN*pi/180) )/2.0;
    Double_t thetadeg_limits[maxcutz+1];
    Double_t DOmegaSr     [maxcutz];
    Double_t DOmegaSrCosef[maxcutz];
    TCut     mycutZenith[maxcutz];
    TCut     mycutTrueZenith[maxcutz];
    Char_t   legendcutZenith[maxcutz][50];

    thetadeg_limits[0] = thetadeg_MIN;
    for(icutz=0; icutz<maxcutz; icutz++)
    {
         //For every zenith angle interval we have the same acceptance
         thetadeg_limits[icutz+1] = (1/2.0)*acos( cos(2*thetadeg_limits[0]*pi/180) - (icutz+1)*2*DOmegaSrCosefMAX_MIN/(pi*maxcutz) )*180/pi;
		 DOmegaSr     [icutz]=-2.0*pi*( cos(thetadeg_limits[icutz+1]*pi/180) - cos(thetadeg_limits[icutz]*pi/180) );
	 	 DOmegaSrCosef[icutz]=-pi*( cos(2*thetadeg_limits[icutz+1]*pi/180) - cos(2*thetadeg_limits[icutz]*pi/180) )/2.0;
         sprintf(mycutexpression, "rec.zenithAngle*180.0/pi>= %f && rec.zenithAngle*180.0/pi<= %f", thetadeg_limits[icutz], thetadeg_limits[icutz+1]);
         mycutZenith[icutz] = mycutexpression;
	 	 sprintf(mycutexpression, "mc.zenithAngle*180.0/pi>= %f && mc.zenithAngle*180.0/pi<= %f", thetadeg_limits[icutz], thetadeg_limits[icutz+1]);
         mycutTrueZenith[icutz] = mycutexpression;
         //sprintf(legendcutZenith[icutz], "%.2f^{o} #leq #theta #leq %.2f^{o}", thetadeg_limits[icutz], thetadeg_limits[icutz+1]);
         sprintf(legendcutZenith[icutz], "#theta = [%.2f^{o}, %.2f^{o}]", thetadeg_limits[icutz], thetadeg_limits[icutz+1]);

         cout << endl;
         cout << DOmegaSr     [icutz] << endl;
    }



    //Reco Energy as a function of zenith angle
    Int_t    icutlogEvsZenith=0;
    Int_t    const maxcutlogEvsZenith = maxcutz;
    Double_t const logEvsZenith_limits    [maxcutz] = {6.4};
    Double_t const logEvsZenith_limits_min[maxcutz] = {2.0};

    TCut     mycutlogEvsZenith    [maxcutlogEvsZenith];
    Char_t   legendcutlogEvsZenith[maxcutlogEvsZenith][100];

    for(icutlogEvsZenith=0; icutlogEvsZenith<maxcutlogEvsZenith; icutlogEvsZenith++)
    {
      sprintf(mycutexpression, "rec.tfout < %.2e && rec.tfout >= %.2e", logEvsZenith_limits[icutlogEvsZenith], logEvsZenith_limits_min[icutlogEvsZenith]);
      mycutlogEvsZenith[icutlogEvsZenith] = mycutexpression;
      sprintf(legendcutlogEvsZenith[icutlogEvsZenith], "log_{10}(E/GeV) = [%.2f, %.2f)",logEvsZenith_limits_min[icutlogEvsZenith], logEvsZenith_limits[icutlogEvsZenith]);
    }
}
