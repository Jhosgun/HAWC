/**
 * @Author: J.A.M.S. <jorge-moralesas>
 * @Date:   2022-02-24T11:44:14-06:00
 * @Email:  jorge.morales@umich.mx
 * @Last modified by:   jorge-moralesas
 * @Last modified time: 2024-02-19T18:01:12-06:00
 */



//Unfolding an energy spectrum
//Same energy range and number of bins for response matrix and spectrum
//Probability must be already normalized inside a logEGeV_True_bin
void  Unfolding(Int_t Iterations, TH1D *NvslogENewAll_Unfolding,  TH2D *h2DResponseMatrixCICvsTrue, TH1D *NvslogENewAll_Unfolded,  TGraphErrors *gEfficiencyvsTrueEnergy)
{
    //Efficiency
    Double_t Eff = 1.0;

	//Smoothing
    Double_t dSmoothpl = 1.5;

    //Read Spectrum
    Int_t  npoints_flux = 0;



    //Get number of bins
    npoints_flux = h2DResponseMatrixCICvsTrue->GetXaxis()->GetNbins();


    //Read Response matrix
    Int_t    irec  = 0, nrec   = h2DResponseMatrixCICvsTrue->GetYaxis()->GetNbins();
    Int_t    itru  = 0, ntru   = h2DResponseMatrixCICvsTrue->GetXaxis()->GetNbins();

    Double_t NumberEvents_LogErec_Set[500] = 0;
    Double_t NumberEvents_LogEtru_Set[500] = 0;


    MatrixlgEGeV_MCCICvsTrue = new TMatrixD(nrec, ntru);


    for(irec = 0;  irec < nrec; irec++)
    {
	for(itru = 0; itru < ntru; itru++)
	{
	    MatrixlgEGeV_MCCICvsTrue(irec, itru) = h2DResponseMatrixCICvsTrue->GetBinContent(itru+1, irec+1);
	}
    }



    //Declare variables for Bayesian algorithm
    Int_t   j=0, i=0;

    Int_t    itera = 0, nitera = Iterations;

    Double_t Suma_numerator = 0.0;
    Double_t Suma_denominator = 0.0;
    Double_t Normalization = 0.0;
    Double_t Probabilities_true_rec[500][500];

    TMatrixD *F_obs   = new TMatrixD(nrec,1);
    TMatrixD *F_truk  = new TMatrixD(ntru,1);
    TMatrixD *F_truk1 = new TMatrixD(ntru,1);
    TMatrixD *M_resp  = new TMatrixD(nrec,ntru);
    TMatrixD *LogE    = new TMatrixD(nrec,1);

    TSpectrum *spectrum = new TSpectrum();
    Float_t auxSmoothing[22];


    //Initialize response matrix
    for(i = 0; i < ntru; i++)
    {
	for(j = 0; j < nrec; j++)
	{

	    M_resp(j,i) = MatrixlgEGeV_MCCICvsTrue(j,i);
	}
    }


    //Initialize flux
    for(j = 0; j < nrec; j++)
    {
	F_obs(j,0) = NvslogENewAll_Unfolding->GetBinContent(j+1);
	LogE (j,0) = NvslogENewAll_Unfolding->GetXaxis()->GetBinCenter(j+1);

	F_truk (j,0) =  NvslogENewAll_Unfolded->GetBinContent(j+1) +  0.0*1.0 + 0.0*10**(-1.5*LogE (j,0));
    F_truk1(j,0) = 0.0;
    }


    //Define function for a polynomial smoothing
    Double_t PointFit_logEGeV_min = 3.0;
    Double_t PointFit_logEGeV_max = 6.0;
    Double_t logE_Smooth = 1.0;
    myfit = new TF1("myfit", "[0]*pow(10**x, [1])", PointFit_logEGeV_min,  PointFit_logEGeV_max);
    //myfit2 = new TF1("myfit2", "[0]*pow(pow(10,x), [1])*pow(1.0 + pow(pow(10,x)/pow(10,[4]),[3]),([2]-[1])/[3])", PointFit_logEGeV_min,  PointFit_logEGeV_max);
    myfit2 = new TF1("myfit2", "[0]*pow(10, x*[1] + x*x*[2])", PointFit_logEGeV_min,  PointFit_logEGeV_max);

    myfitNormaliza = new TF1("myfitNormaliza", "[0]", PointFit_logEGeV_min,  PointFit_logEGeV_max);
	myfit2->SetParLimits(4, 4.0, 5.0);
    myfit2->SetParLimits(3, 3.0, 10.0);

  //Clean histogram with all zenith angles
    if(NvslogENewAll_Unfolded != NULL) NvslogENewAll_Unfolded->Reset();


    //Begin iterations
    for(itera = 0;  itera < nitera; itera++)
    {
	//Calculate P(C|E)
	for(j = 0; j < nrec; j++)
	{
	    Suma_denominator = 0.0;
	    for(Int_t l = 0; l < ntru; l++)
	    {
		Suma_denominator = Suma_denominator + M_resp(j,l)*F_truk(l,0);
	    }




	    Suma_numerator = 0.0;
	    for(i = 0; i < ntru; i++)
	    {

		Suma_numerator = M_resp(j,i)*F_truk(i,0);
		if(Suma_denominator != 0.0) Probabilities_true_rec[i][j] = Suma_numerator/Suma_denominator;
		else                        Probabilities_true_rec[i][j] = 0.0;
	    }
	}


	//Calculate flux using Bayesian method: n^True(C) = P(C|E) n^rec(E) according to D'Agostini paper
	for(j = 0; j < ntru; j++)
	{
        F_truk1(j,0) = 0.0;
	    for(i = 0; i < nrec; i++)
	    {
     		F_truk1(j,0) += Probabilities_true_rec[j][i]*F_obs(i,0);
	    }

	}


	//Prepare arrays for next iteration
	for(i = 0; i < ntru; i++)
	{
	    F_truk (i,0) = F_truk1(i,0);

        Eff = gEfficiencyvsTrueEnergy->Eval(NvslogENewAll_Unfolded->GetBinCenter(i  +1))/37116.0;
        if(Eff == 0) {Eff = 1.0;F_truk(i ,0) = 0.0;}
        F_truk(i , 0) =F_truk(i , 0)/Eff;
	}



	//Smoothing results before using it in the next iteration: Eliminate smoothing by commenting this block
        NvslogENewAll_Unfolded->Reset();
        for(i = 0; i < ntru; i++)
        {
           auxSmoothing[i] = 0.0;
           logE_Smooth = NvslogENewAll_Unfolded->GetBinCenter(i+1);
           NvslogENewAll_Unfolded->SetBinContent(i+1, F_truk(i,0)*pow(10.0, logE_Smooth*dSmoothpl));
           auxSmoothing[i] = NvslogENewAll_Unfolded->GetBinContent(i+1);
            //NvslogENewAll_Unfolded->SetBinContent(i+1, F_truk(i,0));
        }



        //Smoothing using ROOT
        NvslogENewAll_Unfolded->Smooth(1);
        //spectrum->SmoothMarkov(auxSmoothing, 22, 3);

        for(i = 0; i < ntru; i++)
        {
          logE_Smooth = NvslogENewAll_Unfolded->GetBinCenter(i+1);
            //F_truk (i,0)  = NvslogENewAll_Unfolded->GetBinContent(i+1);
            if(logE_Smooth>=3.0){
              F_truk (i,0)  = NvslogENewAll_Unfolded->GetBinContent(i+1)/pow(10.0, logE_Smooth*dSmoothpl);
              //F_truk (i,0)  = auxSmoothing[i]/pow(10.0, logE_Smooth*dSmoothpl);
            }

            Eff = gEfficiencyvsTrueEnergy->Eval(NvslogENewAll_Unfolded->GetBinCenter(i +1))/37116.0;
            if(Eff == 0) {Eff = 1.0;F_truk(i ,0) = 0.0;}
            F_truk(i , 0)=F_truk(i , 0)*Eff;
        }




        //Smoothing with a Polynomial Function
        /*
        if(itera >= 0)
        {
          PointFit_logEGeV_min = 3.0;
          PointFit_logEGeV_max = 6.5;
          for(i = 0; i < ntru; i++)
          {
              logE_Smooth = NvslogENewAll_Unfolded->GetBinCenter(i+1);
               NvslogENewAll_Unfolded->SetBinContent(i+1, F_truk(i,0)*pow(10.0, logE_Smooth*dSmoothpl));
          }

	  	  NvslogENewAll_Unfolded->Fit("myfitNormaliza","Wq","Wq", 4.0, 5.5);
	      myfit->SetParameters (myfitNormaliza->GetParameter(0),  -1.54663e-01);
	      NvslogENewAll_Unfolded->Fit("myfit","q","q",PointFit_logEGeV_min, PointFit_logEGeV_max);
          myfit2->SetParameters (myfit->GetParameter(0), myfit->GetParameter(1), 0);
          NvslogENewAll_Unfolded->Fit("myfit2","q","q",PointFit_logEGeV_min, PointFit_logEGeV_max);


          for(i = 0; i < ntru; i++)
          {

              logE_Smooth = NvslogENewAll_Unfolded->GetBinCenter(i+1);
              if(logE_Smooth >= PointFit_logEGeV_min && logE_Smooth<= PointFit_logEGeV_max)
              {

                  NvslogENewAll_Unfolded->SetBinContent(i+1,  myfit2->Eval(logE_Smooth)/pow(10.0, logE_Smooth*dSmoothpl));
              }
              else
              {

                  NvslogENewAll_Unfolded->SetBinContent(i+1,  NvslogENewAll_Unfolded->GetBinContent(i+1)  /pow(10.0, logE_Smooth*dSmoothpl));
              }

              F_truk (i,0)  = NvslogENewAll_Unfolded->GetBinContent(i+1);

              Eff = gEfficiencyvsTrueEnergy->Eval(NvslogENewAll_Unfolded->GetBinCenter(i +1))/37116.0;
              if(Eff == 0) {Eff = 1.0;F_truk(i ,0) = 0.0;}
              F_truk(i , 0)=F_truk(i , 0)*Eff;


          }
        }//if itera > 0
        */

    }



    //Save unfolded histogram
    NvslogENewAll_Unfolded->Reset();
    for(i = 0; i < ntru; i++)
    {


        NvslogENewAll_Unfolded->SetBinContent(i+1, F_truk1(i, 0));
    }

}











//Forward folding an energy spectrum
//Same energy range and number of bins for response matrix and spectrum
//Probability must be already normalized inside a logEGeV_True_bin
void  Forwardfolding(TH1D *NvslogENewAll_Unfolded,  TH2D *h2DResponseMatrixCICvsTrue, TH1D *NvslogENewAll_Forwardfolded)
{

    //Declare
    Int_t    ibinx_Set=0;


    //Clean histogram with all zenith angles
    if(NvslogENewAll_Forwardfolded != NULL) NvslogENewAll_Forwardfolded->Reset();


    //Declare and initialize variables for algorithm
    Int_t    npoints_flux_Set = h2DResponseMatrixCICvsTrue->GetXaxis()->GetNbins();
    Int_t    irec_Set  = 0, nrec_Set   = npoints_flux_Set;
    Int_t    itru_Set  = 0, ntru_Set   = npoints_flux_Set;

    TMatrixD MatrixlgEGeV_MCCICvsTrue_Set(nrec_Set, ntru_Set);
    for(irec_Set = 0;  irec_Set < nrec_Set; irec_Set++)
    {
	for(itru_Set = 0; itru_Set < ntru_Set; itru_Set++)
	{
	    MatrixlgEGeV_MCCICvsTrue_Set(irec_Set, itru_Set) = h2DResponseMatrixCICvsTrue->GetBinContent(itru_Set+1, irec_Set+1);
	}
    }

    Int_t   j=0, i=0;
    TMatrixD F_obs_Set(nrec_Set,1);
    TMatrixD F_truk_Set(ntru_Set,1);
    TMatrixD M_resp_Set(nrec_Set,ntru_Set);
    TMatrixD LogE_Set(nrec_Set,1);


    //Initialize response matrix
    for(i = 0; i < ntru_Set; i++)
    {
	for(j = 0; j < nrec_Set; j++)
	{

	    M_resp_Set(j,i) = MatrixlgEGeV_MCCICvsTrue_Set(j,i);
	}
    }


    for(j = 0; j < nrec_Set; j++)
    {
	LogE_Set   (j,0) = NvslogENewAll_Unfolded->GetXaxis()->GetBinCenter(j+1);
	F_truk_Set (j,0) = NvslogENewAll_Unfolded->GetBinContent(j+1);

	F_obs_Set(j,0) = 0.0;
    }




    //Apply forward folding
    for(i = 0; i < nrec_Set; i++)
    {
	for(j = 0; j < ntru_Set; j++)
	{
	  F_obs_Set(i,0) = F_obs_Set(i,0) + M_resp_Set(i,j)*F_truk_Set (j,0);
	}
    }



    //Fill Histogram
    NvslogENewAll_Forwardfolded->Reset();
    for(i = 0; i < npoints_flux_Set; i++)
    {
	NvslogENewAll_Forwardfolded->SetBinContent(i+1, F_obs_Set(i, 0));
    }

}
