/**
 * @Author: J.A.M.S. <jorge-moralesas>
 * @Date:   2023-01-03T11:15:39-06:00
 * @Email:  jorge.morales@umich.mx
 * @Last modified by:   jorge-moralesas
 * @Last modified time: 2023-11-29T08:23:11-06:00
 */



//Unfolding an energy spectrum
//Same energy range and number of bins for response matrix and spectrum
//Probability must be already normalized inside a logEGeV_True_bin
void Unfolding(Int_t Iterations, TH1D *NvslogENewAll_Unfolding,  TH2D *h2DResponseMatrixCICvsTrue, TH1D *NvslogENewAll_Unfolded,  TGraphErrors *gEfficiencyvsTrueEnergy)
{

    //Efficiency
    Double_t Eff = 1.0;

	//Smoothing
    Double_t dSmoothpl = 1.5;

   //Read Spectrum
    Int_t  npoints_flux = 0;

    //Clean histogram with all zenith angles



    //Get number of bins
    npoints_flux = h2DResponseMatrixCICvsTrue->GetXaxis()->GetNbins();


    //Read Response matrix
    Int_t    irec  = 0, nrec   = npoints_flux;
    Int_t    itru  = 0, ntru   = npoints_flux;

    Double_t NumberEvents_LogErec_Set[500] = 0;
    Double_t NumberEvents_LogEtru_Set[500] = 0;

    MatrixlgEGeV_MCCICvsTrue = new TMatrixD(nrec, ntru);


    for(irec = 0;  irec < nrec; irec++)
    {
	for(itru = 0; itru < ntru; itru++)
	{
	    MatrixlgEGeV_MCCICvsTrue(irec, itru) = h2DResponseMatrixCICvsTrue->GetBinContent(itru+1, irec+1);
	}
    }



    //Declare variables for Golden algorithm
    Int_t   j=0, i=0;

    Int_t    itera = 0, nitera = Iterations;
    Double_t Sum   = 0;

    TMatrixD *F_obs   = new TMatrixD(nrec,1);
    TMatrixD *F_truk  = new TMatrixD(ntru,1);
    TMatrixD *F_truk1 = new TMatrixD(ntru,1);
    TMatrixD *M_resp  = new TMatrixD(nrec,ntru);

    TMatrixD *LogE    = new TMatrixD(nrec,1);
    Float_t auxSmoothing[22];

    TMatrixD *C       = new TMatrixD(nrec,ntru);



    //Initialize response matrix and Inverse matrix
    for(i = 0; i < ntru; i++)
    {
	for(j = 0; j < nrec; j++)
	{

	    M_resp(j,i) = MatrixlgEGeV_MCCICvsTrue(j,i);
	    C(j,i) = 0.0;
	}
    }


    for(j = 0; j < nrec; j++)
    {
      	F_obs(j,0) = NvslogENewAll_Unfolding->GetBinContent(j+1);
	    LogE (j,0) = NvslogENewAll_Unfolding->GetXaxis()->GetBinCenter(j+1);

	if(F_obs(j,0) == 0.0)
	{
	    C(j,j) = 0.0;
	}
	else
	{
	    C(j,j) = 1.0/sqrt(F_obs(j,0));
	 }


	  F_truk (j,0) =  NvslogENewAll_Unfolded->GetBinContent(j+1) +  0.0*1.0 + 0.0*10**(-1.5*LogE (j,0));
    }

    //Define function for a polynomial smoothing
    Double_t PointFit_logEGeV_min = 3.0;
    Double_t PointFit_logEGeV_max = 6.0;
    Double_t logE_Smooth = 1.0;
    myfit = new TF1("myfit", "[0]*pow(10**x, [1])", PointFit_logEGeV_min,  PointFit_logEGeV_max);
    myfit2 = new TF1("myfit2", "[0]*pow(pow(10,x), [1])*pow(1.0 + pow(pow(10,x)/pow(10,[4]),[3]),([2]-[1])/[3])", PointFit_logEGeV_min,  PointFit_logEGeV_max);
    myfitNormaliza = new TF1("myfitNormaliza", "[0]", PointFit_logEGeV_min,  PointFit_logEGeV_max);
	  myfit2->SetParLimits(4, 4.0, 5.0);
    myfit2->SetParLimits(3, 1.0, 10.0);

    if(NvslogENewAll_Unfolded != NULL) NvslogENewAll_Unfolded->Reset();

    //Van Citter transformation including statistical errors
    MT_M_resp   = new TMatrixD(TMatrixD(*C,TMatrixD::kMult,*M_resp), TMatrixD::kTransposeMult, TMatrixD(*C,TMatrixD::kMult,*M_resp));
    F_prime_obs = new TMatrixD(TMatrixD(*C,TMatrixD::kMult,*M_resp), TMatrixD::kTransposeMult, TMatrixD(*C,TMatrixD::kMult,*F_obs));

    for(itera = 0;  itera < nitera; itera++){
	for(i = 0; i < ntru; i++)
	{
	    F_truk1(i,0) = F_truk(i,0)*F_prime_obs(i,0)/(TMatrixD(*MT_M_resp, TMatrixD::kMult, *F_truk)(i,0));
            if((TMatrixD(*MT_M_resp, TMatrixD::kMult, *F_truk)(i,0)) == 0.0) F_truk1(i,0) =0.0;
	}


	//Prepare arrays for next iteration
	for(i = 0; i < nrec; i++)
	{
	    F_truk (i,0) = F_truk1(i,0);

        Eff = gEfficiencyvsTrueEnergy->Eval(NvslogENewAll_Unfolded->GetBinCenter(i  +1))/37116.0;
        if(Eff == 0) {Eff = 1.0;F_truk(i ,0) = 0.0;}
        F_truk(i , 0) =F_truk(i , 0)/Eff;
	}




	//Smooth results before using it in the next iteration: Eliminate smoothing by commenting this block
  NvslogENewAll_Unfolded->Reset();
  for(i = 0; i < ntru; i++)
  {
     auxSmoothing[i] = 0.0;
     logE_Smooth = NvslogENewAll_Unfolded->GetBinCenter(i+1);
     NvslogENewAll_Unfolded->SetBinContent(i+1, F_truk(i,0)*pow(10.0, logE_Smooth*dSmoothpl));
     auxSmoothing[i] = NvslogENewAll_Unfolded->GetBinContent(i+1);
      //NvslogENewAll_Unfolded->SetBinContent(i+1, F_truk(i,0));
  }



  //Smoothing using ROOT
  NvslogENewAll_Unfolded->Smooth(1);
  //spectrum->SmoothMarkov(auxSmoothing, 22, 3);

  for(i = 0; i < ntru; i++)
  {
    logE_Smooth = NvslogENewAll_Unfolded->GetBinCenter(i+1);
      //F_truk (i,0)  = NvslogENewAll_Unfolded->GetBinContent(i+1);
      if(logE_Smooth>=3.0){
        F_truk (i,0)  = NvslogENewAll_Unfolded->GetBinContent(i+1)/pow(10.0, logE_Smooth*dSmoothpl);
        //F_truk (i,0)  = auxSmoothing[i]/pow(10.0, logE_Smooth*dSmoothpl);
      }

      Eff = gEfficiencyvsTrueEnergy->Eval(NvslogENewAll_Unfolded->GetBinCenter(i +1))/37116.0;
      if(Eff == 0) {Eff = 1.0;F_truk(i ,0) = 0.0;}
      F_truk(i , 0)=F_truk(i , 0)*Eff;
  }



    }


    //Save unfolded histogram
    NvslogENewAll_Unfolded->Reset();
    for(i = 0; i < npoints_flux; i++)
    {
	NvslogENewAll_Unfolded->SetBinContent(i+1, F_truk1(i, 0));
    }
}













//Forward folding an energy spectrum
//Same energy range and number of bins for response matrix and spectrum
//Probability must be already normalized inside a logEGeV_True_bin
void  Forwardfolding(TH1D *NvslogENewAll_Unfolded,  TH2D *h2DResponseMatrixCICvsTrue, TH1D *NvslogENewAll_Forwardfolded)
{

    //Declare
    Int_t    ibinx_Set=0;


    //Clean histogram with all zenith angles
    if(NvslogENewAll_Forwardfolded != NULL) NvslogENewAll_Forwardfolded->Reset();


    //Declare and initialize variables for algorithm
    Int_t    npoints_flux_Set = h2DResponseMatrixCICvsTrue->GetXaxis()->GetNbins();
    Int_t    irec_Set  = 0, nrec_Set   = npoints_flux_Set;
    Int_t    itru_Set  = 0, ntru_Set   = npoints_flux_Set;

    TMatrixD MatrixlgEGeV_MCCICvsTrue_Set(nrec_Set, ntru_Set);
    for(irec_Set = 0;  irec_Set < nrec_Set; irec_Set++)
    {
	for(itru_Set = 0; itru_Set < ntru_Set; itru_Set++)
	{
	    MatrixlgEGeV_MCCICvsTrue_Set(irec_Set, itru_Set) = h2DResponseMatrixCICvsTrue->GetBinContent(itru_Set+1, irec_Set+1);
	}
    }

    Int_t   j=0, i=0;
    TMatrixD F_obs_Set(nrec_Set,1);
    TMatrixD F_truk_Set(ntru_Set,1);
    TMatrixD M_resp_Set(nrec_Set,ntru_Set);
    TMatrixD LogE_Set(nrec_Set,1);


    //Initialize response matrix
    for(i = 0; i < ntru_Set; i++)
    {
	for(j = 0; j < nrec_Set; j++)
	{

	    M_resp_Set(j,i) = MatrixlgEGeV_MCCICvsTrue_Set(j,i);
	}
    }


    for(j = 0; j < nrec_Set; j++)
    {
	LogE_Set   (j,0) = NvslogENewAll_Unfolded->GetXaxis()->GetBinCenter(j+1);
	F_truk_Set (j,0) = NvslogENewAll_Unfolded->GetBinContent(j+1);

	F_obs_Set(j,0) = 0.0;
    }




    //Apply forward folding
    for(i = 0; i < nrec_Set; i++)
    {
	for(j = 0; j < ntru_Set; j++)
	{
	  F_obs_Set(i,0) = F_obs_Set(i,0) + M_resp_Set(i,j)*F_truk_Set (j,0);
	}
    }



    //Fill Histogram
    NvslogENewAll_Forwardfolded->Reset();
    for(i = 0; i < npoints_flux_Set; i++)
    {
	NvslogENewAll_Forwardfolded->SetBinContent(i+1, F_obs_Set(i, 0));
    }

}
