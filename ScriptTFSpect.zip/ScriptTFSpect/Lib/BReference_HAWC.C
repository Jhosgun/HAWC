//Published reference model in All-particle cosmic ray energy spectrum measured by the HAWC experiment from 10 to 500 TeV
//Phys. Rev. D 96, 122001 (2017)
Double_t BReference_Flux_m2ssrGeV_X_Escale(Int_t ncutMass_Set, Double_t logEGeV_Set, Double_t scale)
{
    //Energy spectra of various primary species: broken and double-broken power
    //law fits using data from H. Ahn et al., ApJ 714 (2010) L89-L93.
    //Flux (m^-2 s^-1 sr^-1 GeV)  Energy/particle, GeV
    const  Int_t n_mass_groups = 8;
    Double_t index_before[n_mass_groups]={-2.81,-2.73,-2.76,-2.76,-2.76,-2.76,-2.76,-2.76};
    Double_t index_medium[n_mass_groups]={-2.66,-2.54,-2.55,-2.55,-2.55,-2.55,-2.55,-2.55};
    Double_t norm_F      [n_mass_groups]={4.48e-2,3.31e-2,6.96e-6,5e-6,6.31e-7,5.7e-7,5.7e-7,2e-7};
    Double_t norm_E      [n_mass_groups]={100.0,100.0,1200.0,1600.0,2000.0,2400.0,2800.0,5600.0};
    Double_t Ebreak1     [n_mass_groups]={440.6,854.8,2882,3843,4803,5764,6725,13450};
       
    Double_t Flux_m2ssrGeV_X_Escale = 0.0;
    Int_t select = ncutMass_Set-1;

    TF1 user("user","[0]*pow(10**x/[1],[2])*pow(10**x, [3])",1.0,log10(Ebreak1[select]));
    user.SetParameter(0, norm_F[select]);
    user.FixParameter(1, norm_E[select]);
    user.SetParameter(2, index_before[select]);
    user.FixParameter(3, scale);
    //user.Draw("same");

    TF1 user2("user2","[0]*pow([4]/[1],[2]-[3])*pow(10**x/[1],[3])*pow(10**x, [5])",log10(Ebreak1[select]), 7);
    user2.FixParameter(0,       user.GetParameter(0));
    user2.FixParameter(1,       norm_E[select]);
    user2.FixParameter(2,       user.GetParameter(2));
    user2.SetParameter(3, index_medium[select]);
    user2.FixParameter(4,      Ebreak1[select]);
    user2.FixParameter(5, scale);
    //user2.Draw("same");
    
    if(logEGeV_Set <= log10(Ebreak1[select])) 
      {
   	     Flux_m2ssrGeV_X_Escale = user.Eval(logEGeV_Set);
      }
    else
      {
	     Flux_m2ssrGeV_X_Escale = user2.Eval(logEGeV_Set);
      }

    return Flux_m2ssrGeV_X_Escale;
}
